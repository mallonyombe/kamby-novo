import { STORES } from './data.js';

let cart = JSON.parse(localStorage.getItem('kamby_cart') || '[]');

function save() {
  localStorage.setItem('kamby_cart', JSON.stringify(cart));
  window.dispatchEvent(new CustomEvent('cart-updated', { detail: { cart, count: getCartCount() } }));
}

function findStoreForItem(item) {
  return STORES.find((store) => String(store.id) === String(item.storeId))
    || STORES.find((store) => store.name === item.store)
    || null;
}

export function getCart() {
  return cart;
}

export function addToCart(product, variant, qty = 1) {
  const storeId = product.store?.id || product.storeId || 1;
  const store = STORES.find((itemStore) => String(itemStore.id) === String(storeId));
  const normalizedVariant = variant || product.variants?.find((item) => item.stock > 0) || product.variants?.[0] || {
    id: 'padrao',
    label: 'Padrão',
    price: product.price,
    oldPrice: product.oldPrice ?? null
  };

  const existing = cart.find((item) => item.productId === product.id && item.variant.id === normalizedVariant.id);
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({
      id: `${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      productId: product.id,
      name: product.name,
      img: product.images ? product.images[0] : product.img,
      price: normalizedVariant.price,
      variant: { id: normalizedVariant.id, label: normalizedVariant.label },
      storeId: Number(storeId),
      store: store?.name || product.store?.name || 'Loja Kamby',
      qty
    });
  }
  save();
}

export function updateQty(itemId, delta) {
  const item = cart.find((entry) => entry.id === itemId);
  if (!item) return false;
  const nextQty = Math.max(1, item.qty + delta);
  if (nextQty === item.qty) return false;
  item.qty = nextQty;
  save();
  return true;
}

export function removeFromCart(itemId) {
  cart = cart.filter((entry) => entry.id !== itemId);
  save();
}

export function clearStoreCart(storeIdOrName) {
  cart = cart.filter((item) => String(item.storeId) !== String(storeIdOrName) && item.store !== storeIdOrName);
  save();
}

export function getCartTotal() {
  return cart.reduce((total, item) => total + (item.price * item.qty), 0);
}

export function getCartCount() {
  return cart.reduce((count, item) => count + item.qty, 0);
}

export function getCartGroupedByStore() {
  const grouped = {};
  cart.forEach((item) => {
    const storeRef = findStoreForItem(item);
    const key = storeRef ? String(storeRef.id) : (item.storeId ? String(item.storeId) : item.store);

    if (!grouped[key]) {
      grouped[key] = {
        storeId: storeRef?.id || item.storeId || null,
        storeName: storeRef?.name || item.store || 'Loja Kamby',
        storeArea: storeRef?.area || 'Moçambique',
        storePhone: storeRef?.whatsapp || '258840000000',
        items: [],
        total: 0,
        count: 0
      };
    }

    grouped[key].items.push(item);
    grouped[key].total += item.price * item.qty;
    grouped[key].count += item.qty;
  });
  return Object.values(grouped);
}

export function getStoreCart(storeIdOrName) {
  return getCartGroupedByStore().find((group) => String(group.storeId) === String(storeIdOrName) || group.storeName === storeIdOrName);
}

export function generateWhatsAppOrderUrl(storeCart, customer = null) {
  const phone = storeCart.storePhone.replace(/\D/g, '');

  let msg = `PEDIDO KAMBY EXPRESS\n`;
  msg += `----------------------------------------\n`;
  msg += `Estabelecimento: ${storeCart.storeName}\n`;
  msg += `Localização: ${storeCart.storeArea}\n\n`;
  msg += `Artigos Requisitados:\n`;

  storeCart.items.forEach((item) => {
    const subtotal = item.price * item.qty;
    msg += `- ${item.qty}x ${item.name} (${item.variant.label})\n`;
    msg += `  Subtotal: ${subtotal.toLocaleString('pt-MZ')} MT\n`;
  });

  msg += `----------------------------------------\n`;
  msg += `Valor Total: ${storeCart.total.toLocaleString('pt-MZ')} MT\n`;
  msg += `Modalidade de Envio: Kamby Express (Entrega no mesmo dia)\n`;

  if (customer && (customer.phone || customer.email)) {
    msg += `\nCliente: ${customer.name || 'Cliente Kamby'}\n`;
    if (customer.phone) msg += `Contacto: +258 ${customer.phone}\n`;
    else msg += `Contacto: ${customer.email}\n`;
  }

  msg += `\nConfirmo o pedido acima e solicito as coordenadas para pagamento via M-Pesa ou e-Mola.`;

  return `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
}
