import { getUser, updateProfile } from '../auth.js';
import {
  NAME_MAX,
  SEX_OPTIONS,
  normalizeName,
  normalizeSex,
  sexLabel,
  validateName
} from '../auth-rules.js';
import { ICONS, escapeHtml, triggerHaptic } from '../ui.js';
import {
  beginLoading,
  endLoading,
  renderTextField,
  setBanner,
  setFieldError
} from '../components/form.js';

function errorMessage(code) {
  const messages = {
    'name-short': 'Indica o teu nome completo.',
    'name-long': 'O nome é demasiado longo.',
    'storage-failed': 'Não foi possível guardar os dados neste dispositivo.',
    'no-session': 'A tua sessão expirou. Entra novamente.'
  };
  return messages[code] || 'Não foi possível guardar as alterações. Tenta novamente.';
}

export function renderAccountData() {
  const user = getUser();
  if (!user) return '';

  const name = user.name || '';
  const selectedSex = normalizeSex(user.sex);
  const contactLabel = user.email ? 'Email' : 'Telefone';
  const contactValue = user.email
    ? escapeHtml(user.email)
    : user.phone
      ? `+258 ${escapeHtml(user.phone)}`
      : '';

  return `
    <div class="settings-screen">
      <p class="settings-intro">Atualiza os dados usados na tua conta Kamby.</p>

      <form class="settings-form" id="form-account-data" novalidate>
        <p class="auth-banner" data-banner role="alert" tabindex="-1" hidden></p>

        <div class="settings-card">
          ${renderTextField({
            name: 'name',
            label: 'Nome completo',
            autocomplete: 'name',
            placeholder: 'Ex.: Ana Macuácua',
            value: name,
            maxlength: NAME_MAX,
            inputAttrs: 'autocapitalize="words" spellcheck="false"'
          })}

          <div class="auth-field" data-field="sex">
            <label for="field-sex">Sexo <span class="auth-optional">(opcional)</span></label>
            <button type="button" class="auth-select" id="field-sex" aria-haspopup="dialog">
              <span data-sex-label>${sexLabel(selectedSex)}</span>
              <span class="auth-select-chevron" aria-hidden="true">${ICONS.chevronRight}</span>
            </button>
          </div>
        </div>

        ${contactValue ? `
          <div class="settings-card settings-card-compact">
            <div class="settings-readonly-row">
              <span class="settings-readonly-label">${contactLabel}</span>
              <span class="settings-readonly-value">${contactValue}</span>
            </div>
          </div>
          <p class="settings-note">
            ${user.email ? 'O email identifica a tua conta e não pode ser alterado nesta versão.' : 'O telefone pertence a uma conta antiga e não pode ser alterado aqui.'}
          </p>
        ` : ''}

        <div class="settings-actions">
          <button type="submit" class="k-btn-primary" data-submit disabled>Guardar alterações</button>
        </div>
      </form>
    </div>
  `;
}

function openSexSheet(trigger, selectedSex, onSelect) {
  const sheet = document.getElementById('sheet');
  const backdrop = document.getElementById('sheet-backdrop');
  if (!sheet || !backdrop) return;

  sheet.innerHTML = `
    <div class="k-sheet-handle"></div>
    <div class="k-sheet-header">
      <h2>Sexo</h2>
      <button class="k-sheet-close" onclick="window.closeSheet()" aria-label="Fechar">${ICONS.close}</button>
    </div>
    <p class="auth-sheet-copy">Este dado é opcional e ajuda-nos apenas a personalizar recomendações.</p>
    <div class="auth-choice-list" role="radiogroup" aria-label="Sexo">
      ${SEX_OPTIONS.map((option) => {
        const checked = selectedSex === option.value;
        return `
          <button
            type="button"
            class="auth-choice"
            role="radio"
            aria-checked="${checked}"
            data-sex="${option.value || ''}"
            ${checked ? 'data-autofocus="true"' : ''}
          >
            <span>${option.label}</span>
            <span class="auth-choice-check" aria-hidden="true">${ICONS.check}</span>
          </button>
        `;
      }).join('')}
    </div>
  `;
  sheet.setAttribute('aria-label', 'Sexo');

  sheet.querySelectorAll('[data-sex]').forEach((option) => {
    option.addEventListener('click', () => {
      const value = normalizeSex(option.dataset.sex);
      const label = trigger.querySelector('[data-sex-label]');
      if (label) label.textContent = sexLabel(value);
      onSelect(value);
      triggerHaptic('light');
      window.closeSheet();
    });
  });

  setTimeout(() => {
    sheet.setAttribute('data-open', 'true');
    backdrop.setAttribute('data-open', 'true');
  }, 10);
}

export function initAccountData() {
  const root = document.getElementById('app-view');
  const form = document.getElementById('form-account-data');
  const nameInput = document.getElementById('field-name');
  const sexButton = document.getElementById('field-sex');
  const submit = form?.querySelector('[data-submit]');
  const user = getUser();
  if (!root || !form || !nameInput || !sexButton || !submit || !user) return;

  const initialName = normalizeName(user.name || '');
  let selectedSex = normalizeSex(user.sex);

  const refresh = () => {
    const check = validateName(nameInput.value);
    const dirty = normalizeName(nameInput.value) !== initialName || selectedSex !== normalizeSex(user.sex);
    submit.disabled = !check.ok || !dirty;
    if (check.ok) setFieldError(root, 'name', '');
  };

  nameInput.addEventListener('input', refresh);
  nameInput.addEventListener('blur', () => {
    nameInput.value = normalizeName(nameInput.value);
    const check = validateName(nameInput.value);
    setFieldError(root, 'name', check.ok ? '' : errorMessage(check.code));
    refresh();
  });

  sexButton.addEventListener('click', () => {
    openSexSheet(sexButton, selectedSex, (value) => {
      selectedSex = value;
      refresh();
    });
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (submit.disabled) return;

    const nameCheck = validateName(nameInput.value);
    if (!nameCheck.ok) {
      setFieldError(root, 'name', errorMessage(nameCheck.code));
      nameInput.focus();
      return;
    }

    setBanner(root, '');
    beginLoading(submit, 'A guardar...');
    await new Promise((resolve) => setTimeout(resolve, 300));
    if (!document.body.contains(form)) return;

    const result = updateProfile({ name: nameCheck.name, sex: selectedSex });
    if (!result.ok) {
      endLoading(submit);
      setBanner(root, errorMessage(result.code));
      triggerHaptic('error');
      return;
    }

    triggerHaptic('success');
    window.showToast?.('Dados atualizados');
    window.location.hash = '#/perfil';
  });

  refresh();
}
