import { canChangePassword, deleteAccount, getUser, logout } from '../auth.js';
import { getFavoriteCount } from '../favorites.js';
import { ICONS, escapeHtml, openLegalSheet, triggerHaptic } from '../ui.js';

function favoritesRow() {
  const count = getFavoriteCount();
  return `
    <a class="profile-item" href="#/favoritos">
      <div class="profile-icon">${ICONS.heart}</div>
      <div class="profile-item-info">
        <span class="profile-item-title">Favoritos</span>
      </div>
      ${count > 0 ? `<span class="profile-item-value">${count}</span>` : ''}
      ${ICONS.chevronRight}
    </a>
  `;
}

function supportGroup() {
  return `
    <div class="profile-section-label">Apoio</div>
    <div class="profile-group">
      <div class="profile-item" role="button" tabindex="0" onclick="window.openHelpSheet()">
        <div class="profile-icon">${ICONS.truck}</div>
        <div class="profile-item-info">
          <span class="profile-item-title">Entregas e pagamentos</span>
        </div>
        ${ICONS.chevronRight}
      </div>

      <div class="profile-item" role="button" tabindex="0" onclick="window.openSupportWhatsApp()">
        <div class="profile-icon">${ICONS.whatsapp}</div>
        <div class="profile-item-info">
          <span class="profile-item-title">Falar com a Kamby</span>
        </div>
        ${ICONS.chevronRight}
      </div>

    </div>
  `;
}

function aboutGroup() {
  return `
    <div class="profile-section-label">Sobre</div>
    <div class="profile-group">
      <div class="profile-item" role="button" tabindex="0" id="btn-terms">
        <div class="profile-icon">
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="8" y1="13" x2="16" y2="13"></line><line x1="8" y1="17" x2="14" y2="17"></line></svg>
        </div>
        <div class="profile-item-info">
          <span class="profile-item-title">Termos de Serviço</span>
        </div>
        ${ICONS.chevronRight}
      </div>

      <div class="profile-item" role="button" tabindex="0" id="btn-privacy">
        <div class="profile-icon">
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
        </div>
        <div class="profile-item-info">
          <span class="profile-item-title">Política de Privacidade</span>
        </div>
        ${ICONS.chevronRight}
      </div>
    </div>
  `;
}

export function renderProfile() {
  const user = getUser();

  if (!user) {
    return `
      <div class="profile-header-card">
        <div class="profile-avatar-guest">
          ${ICONS.user}
        </div>

        <h1 class="profile-title">Conta Kamby</h1>
        <p class="profile-subtitle">
          Entra ou cria uma conta para usares os teus dados nas próximas compras.
        </p>

        <button class="k-btn-primary" id="btn-login-profile">
          Entrar
        </button>
        <button class="profile-secondary-btn" id="btn-signup-profile">
          Criar conta
        </button>
      </div>

      <div class="profile-section-label">Conta</div>
      <div class="profile-group">
        ${favoritesRow()}
      </div>
      <p class="profile-section-footer">Os favoritos ficam guardados neste dispositivo.</p>

      ${supportGroup()}
      ${aboutGroup()}

      <div class="profile-version-note">
        Kamby Versão 2.4 (Build 42)
      </div>
    `;
  }

  const safeName = escapeHtml(user.name || 'Cliente Kamby');
  const initial = escapeHtml((user.name || 'K').charAt(0).toUpperCase());
  const contact = user.email
    ? escapeHtml(user.email)
    : user.phone
      ? `+258 ${escapeHtml(user.phone)}`
      : 'Conta Kamby';
  const securityRow = canChangePassword() ? `
    <a class="profile-item" href="#/perfil/seguranca">
      <div class="profile-icon">${ICONS.lock}</div>
      <div class="profile-item-info">
        <span class="profile-item-title">Segurança</span>
      </div>
      ${ICONS.chevronRight}
    </a>
  ` : '';

  return `
    <div class="profile-header-card profile-header-account">
      <div class="profile-avatar-logged">
        <span>${initial}</span>
      </div>
      <div class="profile-account-copy">
        <span class="profile-eyebrow">Conta Kamby</span>
        <h1 class="profile-title">${safeName}</h1>
        <p class="profile-contact-text">${contact}</p>
      </div>
    </div>

    <div class="profile-section-label">Conta</div>
    <div class="profile-group">
      ${favoritesRow()}
      <a class="profile-item" href="#/perfil/dados">
        <div class="profile-icon">${ICONS.user}</div>
        <div class="profile-item-info">
          <span class="profile-item-title">Dados pessoais</span>
        </div>
        ${ICONS.chevronRight}
      </a>
      ${securityRow}
    </div>
    <p class="profile-section-footer">Os favoritos ficam guardados neste dispositivo.</p>

    ${supportGroup()}
    ${aboutGroup()}

    ${user.email ? `
      <div class="profile-group profile-group-danger">
        <div class="profile-item profile-item-danger" role="button" tabindex="0" id="btn-delete-account">
          <div class="profile-icon">${ICONS.trash}</div>
          <div class="profile-item-info">
            <span class="profile-item-title">Eliminar conta</span>
          </div>
          ${ICONS.chevronRight}
        </div>
      </div>
    ` : ''}

    <div class="profile-actions">
      <button class="profile-signout-btn" id="btn-logout">
        Terminar sessão
      </button>
    </div>

    <div class="profile-version-note">
      Kamby Versão 2.4 (Build 42)
    </div>
  `;
}

export function initProfile() {
  const btnLogin = document.getElementById('btn-login-profile');
  if (btnLogin) {
    btnLogin.addEventListener('click', () => {
      triggerHaptic('light');
      window.location.hash = '#/entrar';
    });
  }

  const btnSignup = document.getElementById('btn-signup-profile');
  if (btnSignup) {
    btnSignup.addEventListener('click', () => {
      triggerHaptic('light');
      window.location.hash = '#/criar-conta';
    });
  }

  document.getElementById('btn-terms')?.addEventListener('click', () => openLegalSheet('terms'));
  document.getElementById('btn-privacy')?.addEventListener('click', () => openLegalSheet('privacy'));

  const openDeleteAccountSheet = () => {
    const sheet = document.getElementById('sheet');
    const backdrop = document.getElementById('sheet-backdrop');
    if (!sheet || !backdrop) return;

    sheet.innerHTML = `
      <div class="k-sheet-handle"></div>
      <div class="k-sheet-header">
        <h2>Eliminar conta?</h2>
        <button class="k-sheet-close" onclick="window.closeSheet()" aria-label="Fechar">${ICONS.close}</button>
      </div>
      <p class="profile-sheet-copy">
        Esta ação remove a tua conta Kamby e a sessão deste dispositivo. Não pode ser revertida.
        O carrinho e os favoritos locais mantêm-se.
      </p>
      <button class="profile-danger-btn" id="confirm-delete-account">Eliminar conta</button>
      <button class="auth-text-btn" style="margin-top:6px;" data-autofocus onclick="window.closeSheet()">Cancelar</button>
    `;
    sheet.setAttribute('aria-label', 'Eliminar conta');

    const confirmDelete = document.getElementById('confirm-delete-account');
    confirmDelete?.addEventListener('click', async () => {
      if (confirmDelete.disabled) return;
      confirmDelete.disabled = true;
      confirmDelete.textContent = 'A eliminar...';
      triggerHaptic('medium');

      let result;
      try {
        result = await deleteAccount();
      } catch {
        result = { ok: false };
      }

      if (!result.ok) {
        confirmDelete.disabled = false;
        confirmDelete.textContent = 'Eliminar conta';
        triggerHaptic('error');
        window.showToast?.('Não foi possível eliminar a conta');
        return;
      }
      window.closeSheet();
      window.showToast?.('Conta eliminada');
      window.location.replace('#/');
    });

    setTimeout(() => {
      sheet.setAttribute('data-open', 'true');
      backdrop.setAttribute('data-open', 'true');
      triggerHaptic('light');
    }, 10);
  };

  const btnDelete = document.getElementById('btn-delete-account');
  if (btnDelete) {
    btnDelete.addEventListener('click', openDeleteAccountSheet);
  }

  const btnLogout = document.getElementById('btn-logout');
  if (btnLogout) {
    btnLogout.addEventListener('click', () => {
      triggerHaptic('medium');
      logout();
    });
  }

  window.openSupportWhatsApp = () => {
    triggerHaptic('light');
    const msg = encodeURIComponent("Contacto de suporte Kamby. Solicito esclarecimento sobre um pedido.");
    window.open(`https://wa.me/258841234567?text=${msg}`, '_blank');
  };

  window.openHelpSheet = () => {
    triggerHaptic('light');
    const sheet = document.getElementById('sheet');
    const backdrop = document.getElementById('sheet-backdrop');
    if (!sheet || !backdrop) return;

    sheet.innerHTML = `
      <div class="k-sheet-handle"></div>
      <div class="k-sheet-header">
        <h2>Entregas e pagamentos</h2>
        <button class="k-sheet-close" onclick="window.closeSheet()" aria-label="Fechar">${ICONS.close}</button>
      </div>
      <div class="profile-help-body">
        <div class="profile-help-section">
          <h3>Cobertura</h3>
          <p>Entregas no mesmo dia no centro e bairros de Chongoene, e em zonas selecionadas de Maputo.</p>
        </div>
        <div class="profile-help-section">
          <h3>Processamento</h3>
          <p>O pedido é preparado pela loja após a validação do pagamento.</p>
        </div>
        <div class="profile-help-section">
          <h3>Pagamentos</h3>
          <p>Aceitamos M-Pesa, e-Mola ou numerário na entrega.</p>
        </div>
      </div>
      <button class="k-btn-primary" onclick="window.closeSheet()">Fechar</button>
    `;
    sheet.setAttribute('aria-label', 'Entregas e pagamentos');

    setTimeout(() => {
      sheet.setAttribute('data-open', 'true');
      backdrop.setAttribute('data-open', 'true');
    }, 10);
  };
}
