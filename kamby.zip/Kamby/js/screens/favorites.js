import { getFavoriteProducts, removeFavorite } from '../favorites.js';
import { renderProductCard } from '../components/product-card.js';
import { ICONS, triggerHaptic } from '../ui.js';

function summaryLabel(count) {
  if (count === 0) return '';
  return count === 1 ? '1 artigo guardado' : `${count} artigos guardados`;
}

function emptyState() {
  return `
    <div class="favorites-empty">
      <div class="favorites-empty-icon">${ICONS.heart}</div>
      <h1>Ainda não tens favoritos</h1>
      <p>Toca no coração de um artigo para o guardares aqui.</p>
      <a class="k-btn-primary favorites-explore-btn" href="#/">Explorar artigos</a>
    </div>
    <p class="favorites-footnote">Os favoritos ficam guardados neste dispositivo.</p>
  `;
}

export function renderFavorites() {
  const products = getFavoriteProducts();

  if (products.length === 0) {
    return `<div class="favorites-screen">${emptyState()}</div>`;
  }

  return `
    <div class="favorites-screen">
      <div class="favorites-summary">
        <span id="favorites-count" aria-live="polite">${summaryLabel(products.length)}</span>
        <span class="favorites-summary-note">Neste dispositivo</span>
      </div>

      <div class="k-grid favorites-grid" id="favorites-grid" aria-live="polite">
        ${products.map((product) => renderProductCard(product, {
          removable: true,
          showPromoBadge: false
        })).join('')}
      </div>

      <p class="favorites-footnote">Os favoritos ficam guardados neste dispositivo.</p>
    </div>
  `;
}

export function initFavorites() {
  document.querySelectorAll('[data-favorite-remove]').forEach((button) => {
    button.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();

      const productId = button.dataset.favoriteRemove;
      if (!removeFavorite(productId)) return;

      button.closest('.k-product-card-wrap')?.remove();
      triggerHaptic('medium');
      window.showToast?.('Removido dos favoritos');

      const grid = document.getElementById('favorites-grid');
      const count = grid ? grid.querySelectorAll('.k-product-card-wrap').length : 0;
      const countLabel = document.getElementById('favorites-count');

      if (count === 0) {
        const view = document.getElementById('app-view');
        if (view) {
          view.innerHTML = renderFavorites();
          initFavorites();
        }
        return;
      }

      if (countLabel) countLabel.textContent = summaryLabel(count);
    });
  });
}
