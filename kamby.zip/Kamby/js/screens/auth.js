import {
  DEMO_VERIFICATION_CODE,
  RESEND_COOLDOWN_MS,
  clearPendingAuth,
  getPendingAuth,
  login,
  requestReset,
  resendCode,
  resetVerifiedPassword,
  verifyResetCode,
  startRegistration,
  verifyPendingCode
} from '../auth.js';
import {
  CODE_LENGTH,
  NAME_MAX,
  PASSWORD_MAX,
  SEX_OPTIONS,
  isPasswordValid,
  normalizeCode,
  normalizeEmail,
  normalizeName,
  passwordChecks,
  sexLabel,
  validateCode,
  validateConfirmation,
  validateEmail,
  validateName
} from '../auth-rules.js';
import { ICONS, LOGO_SVG, escapeHtml, openLegalSheet, triggerHaptic } from '../ui.js';

const DRAFT_KEY = 'kamby_signup_draft';
const LOGIN_EMAIL_KEY = 'kamby_login_email';
const MIN_ACTION_DELAY = 450;

let draft = loadDraft();

function getStorage(kind) {
  try {
    return kind === 'session' ? globalThis.sessionStorage : globalThis.localStorage;
  } catch {
    return null;
  }
}

function loadDraft() {
  try {
    const raw = getStorage('session')?.getItem(DRAFT_KEY);
    const parsed = raw ? JSON.parse(raw) : null;
    return {
      name: normalizeName(parsed?.name || ''),
      email: normalizeEmail(parsed?.email || ''),
      sex: parsed?.sex || null
    };
  } catch {
    return { name: '', email: '', sex: null };
  }
}

function saveDraft() {
  try {
    getStorage('session')?.setItem(DRAFT_KEY, JSON.stringify(draft));
  } catch {
    /* draft em memória mantém o fluxo nesta aba */
  }
}

function clearDraft() {
  draft = { name: '', email: '', sex: null };
  try {
    getStorage('session')?.removeItem(DRAFT_KEY);
  } catch {
    /* sem persistência */
  }
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function withMinDelay(promise, ms = MIN_ACTION_DELAY) {
  const [result] = await Promise.all([promise, wait(ms)]);
  return result;
}

function navigate(hash) {
  window.location.hash = hash;
}

function replaceRoute(hash) {
  const normalized = String(hash || '/');
  const next = normalized.startsWith('#') ? normalized : `#${normalized}`;
  if (window.location.hash === next) return;
  window.location.replace(next);
}

function redirectSoon(hash) {
  setTimeout(() => replaceRoute(hash), 0);
  return `<div class="auth-screen auth-screen-redirect" aria-busy="true"></div>`;
}

function topbar({ back = '/perfil', step = 0 } = {}) {
  const center = step
    ? `
      <div class="auth-step">
        <span class="auth-step-label">Passo ${step} de 2</span>
        <div class="auth-progress" aria-hidden="true">
          <span data-active="${step >= 1}"></span>
          <span data-active="${step >= 2}"></span>
        </div>
      </div>
    `
    : '<span></span>';

  return `
    <div class="auth-topbar">
      <button type="button" class="auth-back" data-back="${back}" aria-label="Voltar">${ICONS.back}</button>
      ${center}
      <span class="auth-topbar-spacer" aria-hidden="true"></span>
    </div>
  `;
}

function authGlyph(icon) {
  return `<div class="auth-glyph" aria-hidden="true">${icon}</div>`;
}

function emailChip(email) {
  return `
    <div class="auth-email-chip">
      ${ICONS.mail}
      <span>${escapeHtml(email)}</span>
    </div>
  `;
}

function authHero({ eyebrow, title, copy, email = '', icon }) {
  return `
    <header class="auth-hero">
      ${authGlyph(icon)}
      <div class="auth-hero-copy">
        <span class="auth-eyebrow">${escapeHtml(eyebrow)}</span>
        <h1 tabindex="-1">${escapeHtml(title)}</h1>
        <p>${copy}</p>
        ${email ? emailChip(email) : ''}
      </div>
    </header>
  `;
}

function authSecurityNote(copy) {
  return `
    <p class="auth-security-note">
      ${ICONS.shieldCheck}
      <span>${copy}</span>
    </p>
  `;
}

function inputField({
  name,
  label,
  type = 'text',
  autocomplete = 'off',
  inputmode = '',
  placeholder = '',
  value = '',
  hint = '',
  toggle = false,
  extraClass = '',
  enter = 'next',
  inputAttrs = ''
}) {
  const id = `auth-${name}`;
  const describedBy = `${id}-error${hint ? ` ${id}-hint` : ''}`;
  const trailing = toggle
    ? `<button type="button" class="auth-eye" data-toggle-password="${id}" aria-label="Mostrar palavra-passe" aria-pressed="false">${ICONS.eye}</button>`
    : '';

  return `
    <div class="auth-field" data-field="${name}">
      <label for="${id}">${label}</label>
      <div class="auth-input-shell">
        <input
          class="auth-input ${extraClass}"
          id="${id}"
          name="${name}"
          type="${type}"
          value="${escapeHtml(value)}"
          placeholder="${escapeHtml(placeholder)}"
          autocomplete="${autocomplete}"
          enterkeyhint="${enter}"
          ${inputmode ? `inputmode="${inputmode}"` : ''}
          ${inputAttrs}
          aria-describedby="${describedBy}"
        >
        ${trailing}
      </div>
      ${hint ? `<p class="auth-hint" id="${id}-hint">${hint}</p>` : ''}
      <p class="auth-error" id="${id}-error" aria-live="polite"></p>
    </div>
  `;
}

function codeField() {
  return inputField({
    name: 'code',
    label: 'Código de verificação',
    placeholder: '••••',
    autocomplete: 'one-time-code',
    inputmode: 'numeric',
    extraClass: 'auth-code-input',
    enter: 'done',
    inputAttrs: `maxlength="${CODE_LENGTH}" pattern="[0-9]*" autocapitalize="none" spellcheck="false"`
  });
}

function passwordChecklist() {
  const rules = [
    ['length', '8 a 64 caracteres'],
    ['upper', 'Uma maiúscula'],
    ['lower', 'Uma minúscula'],
    ['digit', 'Um número']
  ];

  return `
    <ul class="auth-rules" aria-label="Requisitos da palavra-passe">
      ${rules.map(([key, label]) => `
        <li class="auth-rule" data-check="${key}">
          <span class="auth-rule-icon" aria-hidden="true">${ICONS.check}</span>
          <span>${label}</span>
          <span class="auth-rule-state k-visually-hidden">Não cumprido</span>
        </li>
      `).join('')}
    </ul>
  `;
}

function setFieldError(root, name, message = '') {
  const field = root.querySelector(`.auth-field[data-field="${name}"]`);
  if (!field) return;
  const input = field.querySelector('input');
  const error = field.querySelector('.auth-error');
  if (input) {
    if (message) input.setAttribute('aria-invalid', 'true');
    else input.removeAttribute('aria-invalid');
  }
  if (error) error.textContent = message;
}

function clearFieldErrors(root) {
  root.querySelectorAll('.auth-field').forEach((field) => {
    if (field.dataset.field) setFieldError(root, field.dataset.field, '');
  });
}

function setBanner(root, message = '', action = null) {
  const banner = root.querySelector('[data-banner]');
  if (!banner) return;
  if (!message) {
    banner.hidden = true;
    banner.innerHTML = '';
    return;
  }
  banner.hidden = false;
  banner.innerHTML = `
    <span>${escapeHtml(message)}</span>
    ${action ? `<button type="button" class="auth-banner-action" data-go="${action.hash}">${escapeHtml(action.label)}</button>` : ''}
  `;
}

function errorMessage(code) {
  const messages = {
    'email-exists': 'Já existe uma conta com este email.',
    'invalid-credentials': 'Email ou palavra-passe incorretos.',
    'invalid-code': 'Código incorreto. Tenta novamente.',
    'too-many-attempts': 'Demasiadas tentativas. Recomeça o processo.',
    'no-pending': 'O pedido expirou. Começa novamente.',
    'not-verified': 'Confirma o código antes de alterares a palavra-passe.',
    'storage-failed': 'Não foi possível guardar os dados neste dispositivo.',
    'password-weak': 'A palavra-passe não cumpre os requisitos.',
    'name-short': 'Indica o teu nome completo.',
    'name-long': 'O nome é demasiado longo.',
    'email-empty': 'Introduz o teu email.',
    'email-invalid': 'Introduz um email válido.'
  };
  return messages[code] || 'Não foi possível concluir a operação. Tenta novamente.';
}

function beginLoading(button, label) {
  if (!button) return;
  button.dataset.idleLabel = button.textContent.trim();
  button.disabled = true;
  button.setAttribute('aria-busy', 'true');
  button.innerHTML = `<span class="k-spinner" aria-hidden="true"></span> ${escapeHtml(label)}`;
}

function endLoading(button) {
  if (!button) return;
  button.removeAttribute('aria-busy');
  button.textContent = button.dataset.idleLabel || 'Continuar';
  button.disabled = false;
}

function focusHeading(root) {
  const heading = root.querySelector('h1');
  if (heading) heading.focus({ preventScroll: true });
}

function updatePasswordRules(root, password) {
  const checks = passwordChecks(password);
  root.querySelectorAll('.auth-rule').forEach((rule) => {
    const met = Boolean(checks[rule.dataset.check]);
    rule.dataset.met = String(met);
    const state = rule.querySelector('.auth-rule-state');
    if (state) state.textContent = met ? 'Cumprido' : 'Não cumprido';
  });
}

function bindCommon(root) {
  root.addEventListener('click', (event) => {
    if (!(event.target instanceof Element)) return;

    const back = event.target.closest('[data-back]');
    if (back?.dataset.back) {
      triggerHaptic('light');
      navigate(back.dataset.back);
      return;
    }

    const go = event.target.closest('[data-go]');
    if (go?.dataset.go) {
      triggerHaptic('light');
      navigate(go.dataset.go);
      return;
    }

    const replace = event.target.closest('[data-replace]');
    if (replace?.dataset.replace) {
      triggerHaptic('light');
      replaceRoute(replace.dataset.replace);
      return;
    }

    const legal = event.target.closest('[data-legal]');
    if (legal?.dataset.legal) {
      openLegalSheet(legal.dataset.legal);
    }
  });

  root.querySelectorAll('[data-toggle-password]').forEach((button) => {
    const input = document.getElementById(button.dataset.togglePassword);
    if (!input) return;
    button.addEventListener('click', () => {
      const showing = input.type === 'text';
      input.type = showing ? 'password' : 'text';
      button.innerHTML = showing ? ICONS.eye : ICONS.eyeOff;
      button.setAttribute('aria-pressed', String(!showing));
      button.setAttribute('aria-label', showing ? 'Mostrar palavra-passe' : 'Ocultar palavra-passe');
      triggerHaptic('light');
      input.focus({ preventScroll: true });
    });
  });
}

function openSexSheet(trigger) {
  const sheet = document.getElementById('sheet');
  const backdrop = document.getElementById('sheet-backdrop');
  if (!sheet || !backdrop) return;

  sheet.innerHTML = `
    <div class="k-sheet-handle"></div>
    <div class="k-sheet-header">
      <h2>Sexo</h2>
      <button class="k-sheet-close" onclick="window.closeSheet()" aria-label="Fechar">${ICONS.close}</button>
    </div>
    <p class="auth-sheet-copy">Este dado é opcional e ajuda-nos apenas a personalizar recomendações.</p>
    <div class="auth-choice-list" role="radiogroup" aria-label="Sexo">
      ${SEX_OPTIONS.map((option) => {
        const checked = (draft.sex || null) === option.value;
        return `
          <button
            type="button"
            class="auth-choice"
            role="radio"
            aria-checked="${checked}"
            data-sex="${option.value || ''}"
            ${checked ? 'data-autofocus="true"' : ''}
          >
            <span>${option.label}</span>
            <span class="auth-choice-check" aria-hidden="true">${ICONS.check}</span>
          </button>
        `;
      }).join('')}
    </div>
  `;
  sheet.setAttribute('aria-label', 'Sexo');

  sheet.querySelectorAll('[data-sex]').forEach((option) => {
    option.addEventListener('click', () => {
      draft.sex = option.dataset.sex || null;
      saveDraft();
      const label = trigger.querySelector('[data-sex-label]');
      if (label) label.textContent = sexLabel(draft.sex);
      triggerHaptic('light');
      window.closeSheet();
    });
  });

  setTimeout(() => {
    sheet.setAttribute('data-open', 'true');
    backdrop.setAttribute('data-open', 'true');
  }, 10);
}

function startCooldown(button, sentAt) {
  if (!button) return;
  let remaining = Math.max(0, Math.min(RESEND_COOLDOWN_MS, RESEND_COOLDOWN_MS - (Date.now() - (Number(sentAt) || 0))));

  const render = () => {
    if (!button.isConnected) return false;
    if (remaining > 0) {
      button.disabled = true;
      button.textContent = `Reenviar em ${Math.ceil(remaining / 1000)}s`;
    } else {
      button.disabled = false;
      button.textContent = 'Reenviar código';
    }
    return true;
  };

  render();
  const timer = setInterval(() => {
    remaining -= 1000;
    if (!render() || remaining <= 0) clearInterval(timer);
  }, 1000);
}

function renderSuccess(root, { title, message, autoHash = '', autoDelay = 0, action = null }) {
  root.classList.add('auth-screen-success');
  root.innerHTML = `
    <div class="auth-glow auth-glow-a" aria-hidden="true"></div>
    <div class="auth-glow auth-glow-b" aria-hidden="true"></div>
    <div class="auth-success" role="status" aria-live="polite">
      <div class="auth-success-ring">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <path class="auth-check-path" d="M4.5 12.5l4.6 4.6L19.5 6.7"></path>
        </svg>
      </div>
      <h1 tabindex="-1">${escapeHtml(title)}</h1>
      <p>${escapeHtml(message)}</p>
      ${action ? `<button type="button" class="k-btn-primary auth-success-action" data-go="${action.hash}">${escapeHtml(action.label)}</button>` : ''}
    </div>
  `;

  const heading = root.querySelector('h1');
  if (heading) heading.focus({ preventScroll: true });

  if (autoHash) {
    setTimeout(() => {
      if (root.isConnected) replaceRoute(autoHash);
    }, autoDelay);
  }
}

function renderWelcome() {
  return `
    <div class="auth-screen auth-welcome">
      <div class="auth-glow auth-glow-a" aria-hidden="true"></div>
      <div class="auth-glow auth-glow-b" aria-hidden="true"></div>

      <div class="welcome-top">
        <div class="welcome-logo">${LOGO_SVG}</div>
        <h1 tabindex="-1">Compras locais,<br>sem complicações.</h1>
        <p class="welcome-sub">Lojas verificadas em Chongoene e Maputo, entrega no mesmo dia e checkout direto no WhatsApp.</p>
      </div>

      <ul class="welcome-benefits">
        <li>
          <span class="welcome-benefit-icon">${ICONS.verified}</span>
          <span><strong>Lojas locais verificadas</strong><small>Comerciantes da tua zona, num só lugar.</small></span>
        </li>
        <li>
          <span class="welcome-benefit-icon">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="1" y="5" width="14" height="12" rx="1.5"></rect><path d="M15 9h4l3 3v5h-7z"></path><circle cx="5.5" cy="19" r="1.8"></circle><circle cx="18" cy="19" r="1.8"></circle></svg>
          </span>
          <span><strong>Kamby Express</strong><small>Entrega no mesmo dia na zona de cobertura.</small></span>
        </li>
        <li>
          <span class="welcome-benefit-icon">${ICONS.whatsapp}</span>
          <span><strong>Checkout no WhatsApp</strong><small>Confirma o pedido diretamente com a loja.</small></span>
        </li>
      </ul>

      <div class="welcome-actions">
        <button type="button" class="k-btn-primary" data-go="/criar-conta">Criar conta</button>
        <button type="button" class="auth-btn-secondary" data-go="/entrar">Já tenho conta</button>
        <button type="button" class="auth-text-btn" data-replace="/">Continuar como visitante</button>
      </div>

      <p class="welcome-legal">
        <button type="button" class="auth-legal-link" data-legal="terms">Termos de Serviço</button>
        <span aria-hidden="true">·</span>
        <button type="button" class="auth-legal-link" data-legal="privacy">Política de Privacidade</button>
      </p>
    </div>
  `;
}

function renderIdentity() {
  return `
    <div class="auth-screen">
      <div class="auth-glow auth-glow-a" aria-hidden="true"></div>
      ${topbar({ back: '/bem-vindo', step: 1 })}

      <div class="auth-content">
        <header class="auth-heading">
          <h1 tabindex="-1">Criar conta</h1>
          <p>Usa o nome como queres que a loja te trate. Leva menos de um minuto.</p>
        </header>

        <form class="auth-form" id="form-identity" novalidate>
          ${inputField({
            name: 'name',
            label: 'Nome completo',
            autocomplete: 'name',
            placeholder: 'Ex.: Ana Macuácua',
            value: draft.name,
            inputAttrs: `autocapitalize="words" spellcheck="false" maxlength="${NAME_MAX}"`
          })}

          <div class="auth-field" data-field="sex">
            <label for="auth-sex">Sexo <span class="auth-optional">(opcional)</span></label>
            <button type="button" class="auth-select" id="auth-sex" aria-haspopup="dialog">
              <span data-sex-label>${sexLabel(draft.sex)}</span>
              <span class="auth-select-chevron" aria-hidden="true">${ICONS.chevronRight}</span>
            </button>
          </div>

          ${inputField({
            name: 'email',
            label: 'Email',
            type: 'email',
            autocomplete: 'email',
            inputmode: 'email',
            placeholder: 'nome@exemplo.com',
            value: draft.email,
            inputAttrs: 'autocapitalize="none" autocorrect="off" spellcheck="false" maxlength="254"'
          })}

          <div class="auth-actions">
            <button type="submit" class="k-btn-primary" data-submit disabled>Continuar</button>
          </div>
        </form>

        <p class="auth-alt">Já tens conta? <button type="button" class="auth-link" data-go="/entrar">Entrar</button></p>
      </div>
    </div>
  `;
}

function renderSecurity() {
  return `
    <div class="auth-screen">
      <div class="auth-glow auth-glow-b" aria-hidden="true"></div>
      ${topbar({ back: '/criar-conta', step: 2 })}

      <div class="auth-content auth-content-product">
        ${authHero({
          eyebrow: 'Conta nova',
          title: 'Cria a tua palavra-passe',
          copy: 'Uma chave única protege os teus dados e mantém o carrinho associado à tua conta.',
          email: draft.email,
          icon: ICONS.shieldCheck
        })}

        <form class="auth-form auth-form-product" id="form-security" novalidate>
          <p class="auth-banner" data-banner role="alert" tabindex="-1" hidden></p>

          <div class="auth-panel">
            <div class="auth-panel-header">
              <div>
                <span class="auth-panel-kicker">Segurança</span>
                <h2>Palavra-passe</h2>
              </div>
              <span class="auth-panel-badge">Obrigatório</span>
            </div>

            ${inputField({
              name: 'password',
              label: 'Palavra-passe',
              type: 'password',
              autocomplete: 'new-password',
              toggle: true,
              enter: 'next',
              inputAttrs: `autocapitalize="none" spellcheck="false" maxlength="${PASSWORD_MAX}"`
            })}

            ${passwordChecklist()}

            ${inputField({
              name: 'confirm',
              label: 'Confirmar palavra-passe',
              type: 'password',
              autocomplete: 'new-password',
              toggle: true,
              enter: 'done',
              inputAttrs: `autocapitalize="none" spellcheck="false" maxlength="${PASSWORD_MAX}"`
            })}
          </div>

          ${authSecurityNote('Nunca uses uma palavra-passe que já utilizas noutro serviço.')}

          <p class="auth-legal">
            Ao criares conta, concordas com os
            <button type="button" class="auth-legal-link" data-legal="terms">Termos de Serviço</button>
            e a
            <button type="button" class="auth-legal-link" data-legal="privacy">Política de Privacidade</button>.
          </p>

          <div class="auth-actions">
            <button type="submit" class="k-btn-primary" data-submit disabled>Criar conta</button>
          </div>
        </form>

        <p class="auth-alt">Já tens conta? <button type="button" class="auth-link" data-go="/entrar">Entrar</button></p>
      </div>
    </div>
  `;
}

function renderVerification() {
  const pending = getPendingAuth();
  if (!pending || pending.kind !== 'verify') return redirectSoon('/entrar');

  return `
    <div class="auth-screen">
      <div class="auth-glow auth-glow-a" aria-hidden="true"></div>
      ${topbar({ back: '/criar-conta' })}

      <div class="auth-content">
        <header class="auth-heading">
          <h1 tabindex="-1">Verifica o teu email</h1>
          <p>Enviámos um código de ${CODE_LENGTH} dígitos para <strong>${escapeHtml(pending.email)}</strong>.</p>
        </header>

        <form class="auth-form" id="form-verification" novalidate>
          <p class="auth-banner" data-banner role="alert" tabindex="-1" hidden></p>

          ${codeField()}

          <p class="auth-demo-note">Código de teste: <strong>${DEMO_VERIFICATION_CODE}</strong></p>

          <div class="auth-actions">
            <button type="submit" class="k-btn-primary" data-submit disabled>Verificar conta</button>
          </div>

          <button type="button" class="auth-text-btn auth-resend" id="auth-resend">Reenviar código</button>
        </form>

        <p class="auth-alt"><button type="button" class="auth-link" data-go="/criar-conta">Alterar email</button></p>
      </div>
    </div>
  `;
}

function renderLogin() {
  let loginHint = '';
  try {
    loginHint = getStorage('session')?.getItem(LOGIN_EMAIL_KEY) || '';
    getStorage('session')?.removeItem(LOGIN_EMAIL_KEY);
  } catch {
    loginHint = '';
  }

  return `
    <div class="auth-screen">
      <div class="auth-glow auth-glow-b" aria-hidden="true"></div>
      ${topbar({ back: '/perfil' })}

      <div class="auth-content">
        <header class="auth-heading">
          <h1 tabindex="-1">Entrar</h1>
          <p>Usa o email e a palavra-passe da tua conta Kamby.</p>
        </header>

        <form class="auth-form" id="form-login" novalidate>
          <p class="auth-banner" data-banner role="alert" tabindex="-1" hidden></p>

          ${inputField({
            name: 'email',
            label: 'Email',
            type: 'email',
            autocomplete: 'username',
            inputmode: 'email',
            placeholder: 'nome@exemplo.com',
            value: loginHint,
            inputAttrs: 'autocapitalize="none" autocorrect="off" spellcheck="false" maxlength="254"'
          })}

          ${inputField({
            name: 'password',
            label: 'Palavra-passe',
            type: 'password',
            autocomplete: 'current-password',
            toggle: true,
            enter: 'done',
            inputAttrs: `autocapitalize="none" spellcheck="false" maxlength="${PASSWORD_MAX}"`
          })}

          <div class="auth-forgot">
            <button type="button" class="auth-link" data-go="/recuperar">Esqueceste-te da palavra-passe?</button>
          </div>

          <div class="auth-actions">
            <button type="submit" class="k-btn-primary" data-submit disabled>Entrar</button>
          </div>
        </form>

        <p class="auth-alt">Novo no Kamby? <button type="button" class="auth-link" data-go="/criar-conta">Criar conta</button></p>
      </div>
    </div>
  `;
}

function renderRecover() {
  return `
    <div class="auth-screen">
      <div class="auth-glow auth-glow-a" aria-hidden="true"></div>
      ${topbar({ back: '/entrar' })}

      <div class="auth-content">
        <header class="auth-heading">
          <h1 tabindex="-1">Recuperar palavra-passe</h1>
          <p>Indica o email da tua conta. Depois vamos pedir-te um código e uma nova palavra-passe.</p>
        </header>

        <form class="auth-form" id="form-recover" novalidate>
          <p class="auth-banner" data-banner role="alert" tabindex="-1" hidden></p>

          ${inputField({
            name: 'email',
            label: 'Email',
            type: 'email',
            autocomplete: 'email',
            inputmode: 'email',
            placeholder: 'nome@exemplo.com',
            inputAttrs: 'autocapitalize="none" autocorrect="off" spellcheck="false" maxlength="254"'
          })}

          <p class="auth-note">Por segurança, não confirmamos se o email existe. Se houver uma conta, receberás as instruções.</p>

          <div class="auth-actions">
            <button type="submit" class="k-btn-primary" data-submit disabled>Enviar instruções</button>
          </div>
        </form>

        <p class="auth-alt"><button type="button" class="auth-link" data-go="/entrar">Voltar a entrar</button></p>
      </div>
    </div>
  `;
}

function renderResetCode() {
  const pending = getPendingAuth();
  if (!pending || pending.kind !== 'reset') return redirectSoon('/recuperar');
  if (pending.verified) return redirectSoon('/recuperar/nova-palavra-passe');

  return `
    <div class="auth-screen">
      <div class="auth-glow auth-glow-b" aria-hidden="true"></div>
      ${topbar({ back: '/recuperar', step: 1 })}

      <div class="auth-content auth-content-product">
        ${authHero({
          eyebrow: 'Recuperar conta',
          title: 'Verifica o teu email',
          copy: 'Introduz o código de segurança antes de escolheres uma nova palavra-passe.',
          email: pending.email,
          icon: ICONS.shieldCheck
        })}

        <form class="auth-form auth-form-product" id="form-reset-code" novalidate>
          <p class="auth-banner" data-banner role="alert" tabindex="-1" hidden></p>

          <div class="auth-panel">
            <div class="auth-panel-header">
              <div>
                <span class="auth-panel-kicker">Passo 1</span>
                <h2>Código de segurança</h2>
              </div>
              <span class="auth-panel-badge">${CODE_LENGTH} dígitos</span>
            </div>

            ${codeField()}
            <p class="auth-demo-note">Código de teste: <strong>${DEMO_VERIFICATION_CODE}</strong></p>
          </div>

          ${authSecurityNote('A palavra-passe só pode ser alterada depois da confirmação deste código.')}

          <div class="auth-actions">
            <button type="submit" class="k-btn-primary" data-submit disabled>Verificar código</button>
          </div>

          <button type="button" class="auth-text-btn auth-resend" id="auth-resend">Reenviar código</button>
        </form>
      </div>
    </div>
  `;
}

function renderResetPassword() {
  const pending = getPendingAuth();
  if (!pending || pending.kind !== 'reset') return redirectSoon('/recuperar');
  if (!pending.verified) return redirectSoon('/recuperar/codigo');

  return `
    <div class="auth-screen">
      <div class="auth-glow auth-glow-b" aria-hidden="true"></div>
      ${topbar({ back: '/recuperar', step: 2 })}

      <div class="auth-content auth-content-product">
        ${authHero({
          eyebrow: 'Recuperar conta',
          title: 'Cria a tua nova palavra-passe',
          copy: 'Usa uma combinação que não estejas a usar noutro serviço.',
          email: pending.email,
          icon: ICONS.lock
        })}

        <form class="auth-form auth-form-product" id="form-reset" novalidate>
          <p class="auth-banner" data-banner role="alert" tabindex="-1" hidden></p>

          <div class="auth-panel">
            <div class="auth-panel-header">
              <div>
                <span class="auth-panel-kicker">Passo 2</span>
                <h2>Nova palavra-passe</h2>
              </div>
              <span class="auth-panel-badge">Obrigatório</span>
            </div>

            ${inputField({
              name: 'password',
              label: 'Nova palavra-passe',
              type: 'password',
              autocomplete: 'new-password',
              toggle: true,
              enter: 'next',
              inputAttrs: `autocapitalize="none" spellcheck="false" maxlength="${PASSWORD_MAX}"`
            })}

            ${passwordChecklist()}

            ${inputField({
              name: 'confirm',
              label: 'Confirmar nova palavra-passe',
              type: 'password',
              autocomplete: 'new-password',
              toggle: true,
              enter: 'done',
              inputAttrs: `autocapitalize="none" spellcheck="false" maxlength="${PASSWORD_MAX}"`
            })}
          </div>

          ${authSecurityNote('Depois de guardares, a palavra-passe anterior deixa de funcionar.')}

          <div class="auth-actions">
            <button type="submit" class="k-btn-primary" data-submit disabled>Guardar nova palavra-passe</button>
          </div>
        </form>
      </div>
    </div>
  `;
}

export function renderAuthScreen(route) {
  switch (route) {
    case '/bem-vindo':
      return renderWelcome();
    case '/criar-conta':
      return renderIdentity();
    case '/criar-conta/seguranca':
      return draft.name && draft.email ? renderSecurity() : redirectSoon('/criar-conta');
    case '/criar-conta/verificar':
      return renderVerification();
    case '/entrar':
      return renderLogin();
    case '/recuperar':
      return renderRecover();
    case '/recuperar/codigo':
      return renderResetCode();
    case '/recuperar/nova-palavra-passe':
      return renderResetPassword();
    default:
      return '';
  }
}

export function initAuthScreen(route) {
  const root = document.querySelector('.auth-screen');
  if (!root) return;
  bindCommon(root);
  focusHeading(root);

  switch (route) {
    case '/bem-vindo':
      return;
    case '/criar-conta':
      initIdentity(root);
      return;
    case '/criar-conta/seguranca':
      initSecurity(root);
      return;
    case '/criar-conta/verificar':
      initVerification(root);
      return;
    case '/entrar':
      initLogin(root);
      return;
    case '/recuperar':
      initRecover(root);
      return;
    case '/recuperar/codigo':
      initResetCode(root);
      return;
    case '/recuperar/nova-palavra-passe':
      initResetPassword(root);
      return;
    default:
  }
}

function initIdentity(root) {
  const form = root.querySelector('#form-identity');
  const nameInput = root.querySelector('#auth-name');
  const emailInput = root.querySelector('#auth-email');
  const sexSelect = root.querySelector('#auth-sex');
  const submit = root.querySelector('[data-submit]');
  if (!form || !nameInput || !emailInput || !submit) return;

  nameInput.value = draft.name;
  emailInput.value = draft.email;

  const refresh = () => {
    submit.disabled = !(validateName(nameInput.value).ok && validateEmail(emailInput.value).ok);
    if (validateName(nameInput.value).ok) setFieldError(root, 'name', '');
    if (validateEmail(emailInput.value).ok) setFieldError(root, 'email', '');
  };

  nameInput.addEventListener('blur', () => {
    const value = normalizeName(nameInput.value);
    nameInput.value = value;
    const check = validateName(value);
    setFieldError(root, 'name', check.ok ? '' : errorMessage(check.code));
    refresh();
  });

  emailInput.addEventListener('blur', () => {
    const value = normalizeEmail(emailInput.value);
    emailInput.value = value;
    const check = validateEmail(value);
    setFieldError(root, 'email', check.ok ? '' : errorMessage(check.code));
    refresh();
  });

  form.addEventListener('input', refresh);

  sexSelect?.addEventListener('click', () => openSexSheet(sexSelect));

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const name = normalizeName(nameInput.value);
    const email = normalizeEmail(emailInput.value);
    const nameCheck = validateName(name);
    const emailCheck = validateEmail(email);

    if (!nameCheck.ok) setFieldError(root, 'name', errorMessage(nameCheck.code));
    if (!emailCheck.ok) setFieldError(root, 'email', errorMessage(emailCheck.code));

    if (!nameCheck.ok) {
      nameInput.focus();
      return;
    }
    if (!emailCheck.ok) {
      emailInput.focus();
      return;
    }

    draft = { ...draft, name: nameCheck.name, email: emailCheck.email };
    saveDraft();
    triggerHaptic('light');
    navigate('/criar-conta/seguranca');
  });

  refresh();
}

function initSecurity(root) {
  const form = root.querySelector('#form-security');
  const passwordInput = root.querySelector('#auth-password');
  const confirmInput = root.querySelector('#auth-confirm');
  const submit = root.querySelector('[data-submit]');
  if (!form || !passwordInput || !confirmInput || !submit) return;

  const refresh = () => {
    updatePasswordRules(root, passwordInput.value);
    const passwordOk = isPasswordValid(passwordInput.value);
    const matches = validateConfirmation(passwordInput.value, confirmInput.value);
    if (passwordOk) setFieldError(root, 'password', '');
    if (matches || !confirmInput.value) setFieldError(root, 'confirm', '');
    submit.disabled = !(passwordOk && confirmInput.value && matches);
  };

  form.addEventListener('input', refresh);

  confirmInput.addEventListener('blur', () => {
    if (confirmInput.value && !validateConfirmation(passwordInput.value, confirmInput.value)) {
      setFieldError(root, 'confirm', 'As palavras-passe não coincidem.');
    }
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    clearFieldErrors(root);
    setBanner(root, '');

    const passwordCheck = isPasswordValid(passwordInput.value);
    const matches = validateConfirmation(passwordInput.value, confirmInput.value);

    if (!passwordCheck) {
      setFieldError(root, 'password', errorMessage('password-weak'));
      updatePasswordRules(root, passwordInput.value);
      passwordInput.focus();
      triggerHaptic('error');
      return;
    }
    if (!matches) {
      setFieldError(root, 'confirm', 'As palavras-passe não coincidem.');
      confirmInput.focus();
      triggerHaptic('error');
      return;
    }

    beginLoading(submit, 'A criar conta...');
    let result;
    try {
      result = await withMinDelay(startRegistration(draft, passwordInput.value));
    } catch {
      result = { ok: false, code: 'storage-failed' };
    }
    endLoading(submit);

    if (!result.ok) {
      triggerHaptic('error');
      submit.disabled = false;
      if (result.code === 'email-exists') {
        setBanner(root, errorMessage(result.code), { hash: '/entrar', label: 'Entrar' });
        return;
      }
      setBanner(root, errorMessage(result.code));
      return;
    }

    triggerHaptic('success');
    navigate('/criar-conta/verificar');
  });

  refresh();
}

function initVerification(root) {
  const pending = getPendingAuth();
  if (!pending || pending.kind !== 'verify') {
    replaceRoute('/entrar');
    return;
  }

  const form = root.querySelector('#form-verification');
  const codeInput = root.querySelector('#auth-code');
  const submit = root.querySelector('[data-submit]');
  const resend = root.querySelector('#auth-resend');
  if (!form || !codeInput || !submit) return;

  const refresh = () => {
    submit.disabled = !validateCode(codeInput.value);
  };

  codeInput.addEventListener('input', () => {
    codeInput.value = normalizeCode(codeInput.value);
    if (validateCode(codeInput.value)) setFieldError(root, 'code', '');
    refresh();
  });

  resend?.addEventListener('click', async () => {
    resend.disabled = true;
    const result = await resendCode();
    if (result.ok) {
      window.showToast?.('Código reenviado');
      startCooldown(resend, result.sentAt);
    } else if (result.code === 'cooldown') {
      startCooldown(resend, Date.now() - (RESEND_COOLDOWN_MS - result.waitMs));
    } else if (result.code === 'no-pending') {
      replaceRoute('/entrar');
    } else {
      triggerHaptic('error');
      setBanner(root, errorMessage(result.code));
      startCooldown(resend, pending.sentAt);
    }
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    setBanner(root, '');
    setFieldError(root, 'code', '');

    if (!validateCode(codeInput.value)) {
      setFieldError(root, 'code', 'Introduz os 4 dígitos do código.');
      codeInput.focus();
      return;
    }

    beginLoading(submit, 'A verificar...');
    let result;
    try {
      result = await withMinDelay(verifyPendingCode(codeInput.value));
    } catch {
      result = { ok: false, code: 'storage-failed' };
    }
    endLoading(submit);

    if (result.ok) {
      clearDraft();
      clearPendingAuth();
      triggerHaptic('success');
      const firstName = (result.user?.name || '').split(' ')[0] || 'Cliente';
      renderSuccess(root, {
        title: 'Conta criada',
        message: `Bem-vindo ao Kamby, ${firstName}.`,
        autoHash: '/perfil',
        autoDelay: 1100
      });
      return;
    }

    triggerHaptic('error');
    submit.disabled = false;
    if (result.code === 'invalid-code') {
      setFieldError(root, 'code', 'Código incorreto. Tenta novamente.');
      codeInput.value = '';
      codeInput.focus();
    } else if (result.code === 'too-many-attempts') {
      setBanner(root, errorMessage(result.code), { hash: '/criar-conta', label: 'Recomeçar' });
      codeInput.disabled = true;
      submit.disabled = true;
      if (resend) resend.disabled = true;
    } else if (result.code === 'email-exists') {
      setBanner(root, errorMessage(result.code), { hash: '/entrar', label: 'Entrar' });
      codeInput.disabled = true;
      submit.disabled = true;
      if (resend) resend.disabled = true;
    } else if (result.code === 'no-pending') {
      replaceRoute('/entrar');
    } else {
      setBanner(root, errorMessage(result.code));
    }
  });

  startCooldown(resend, pending.sentAt);
  refresh();
}

function initLogin(root) {
  const form = root.querySelector('#form-login');
  const emailInput = root.querySelector('#auth-email');
  const passwordInput = root.querySelector('#auth-password');
  const submit = root.querySelector('[data-submit]');
  if (!form || !emailInput || !passwordInput || !submit) return;

  const refresh = () => {
    submit.disabled = !(validateEmail(emailInput.value).ok && passwordInput.value.length > 0);
    if (validateEmail(emailInput.value).ok) setFieldError(root, 'email', '');
  };

  form.addEventListener('input', refresh);

  emailInput.addEventListener('blur', () => {
    const value = normalizeEmail(emailInput.value);
    emailInput.value = value;
    const check = validateEmail(value);
    setFieldError(root, 'email', check.ok ? '' : errorMessage(check.code));
    refresh();
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    setBanner(root, '');
    clearFieldErrors(root);

    const emailCheck = validateEmail(emailInput.value);
    if (!emailCheck.ok) {
      setFieldError(root, 'email', errorMessage(emailCheck.code));
      emailInput.focus();
      return;
    }
    if (!passwordInput.value) {
      setFieldError(root, 'password', 'Introduz a tua palavra-passe.');
      passwordInput.focus();
      return;
    }

    beginLoading(submit, 'A entrar...');
    let result;
    try {
      result = await withMinDelay(login(emailInput.value, passwordInput.value));
    } catch {
      result = { ok: false, code: 'invalid-credentials' };
    }
    endLoading(submit);

    if (!result.ok) {
      triggerHaptic('error');
      submit.disabled = false;
      setBanner(root, errorMessage(result.code));
      setFieldError(root, 'password', errorMessage(result.code));
      passwordInput.focus();
      passwordInput.select?.();
      return;
    }

    const firstName = (result.user?.name || '').split(' ')[0] || 'Cliente';
    window.showToast?.(`Bem-vindo de volta, ${firstName}!`);
    replaceRoute('/perfil');
  });

  refresh();
}

function initRecover(root) {
  const form = root.querySelector('#form-recover');
  const emailInput = root.querySelector('#auth-email');
  const submit = root.querySelector('[data-submit]');
  if (!form || !emailInput || !submit) return;

  const refresh = () => {
    submit.disabled = !validateEmail(emailInput.value).ok;
    if (validateEmail(emailInput.value).ok) setFieldError(root, 'email', '');
  };

  form.addEventListener('input', refresh);

  emailInput.addEventListener('blur', () => {
    const value = normalizeEmail(emailInput.value);
    emailInput.value = value;
    const check = validateEmail(value);
    setFieldError(root, 'email', check.ok ? '' : errorMessage(check.code));
    refresh();
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    setBanner(root, '');
    setFieldError(root, 'email', '');

    const emailCheck = validateEmail(emailInput.value);
    if (!emailCheck.ok) {
      setFieldError(root, 'email', errorMessage(emailCheck.code));
      emailInput.focus();
      return;
    }

    beginLoading(submit, 'A enviar...');
    let result;
    try {
      result = await withMinDelay(requestReset(emailCheck.email));
    } catch {
      result = { ok: false, code: 'storage-failed' };
    }
    endLoading(submit);

    if (!result.ok) {
      triggerHaptic('error');
      submit.disabled = false;
      setBanner(root, errorMessage(result.code));
      return;
    }

    triggerHaptic('success');
    navigate('/recuperar/codigo');
  });

  refresh();
}

function initResetCode(root) {
  const pending = getPendingAuth();
  if (!pending || pending.kind !== 'reset') {
    replaceRoute('/recuperar');
    return;
  }
  if (pending.verified) {
    replaceRoute('/recuperar/nova-palavra-passe');
    return;
  }

  const form = root.querySelector('#form-reset-code');
  const codeInput = root.querySelector('#auth-code');
  const submit = root.querySelector('[data-submit]');
  const resend = root.querySelector('#auth-resend');
  if (!form || !codeInput || !submit) return;

  const refresh = () => {
    submit.disabled = !validateCode(codeInput.value);
  };

  codeInput.addEventListener('input', () => {
    codeInput.value = normalizeCode(codeInput.value);
    if (validateCode(codeInput.value)) setFieldError(root, 'code', '');
    refresh();
  });

  resend?.addEventListener('click', async () => {
    resend.disabled = true;
    const result = await resendCode();
    if (result.ok) {
      window.showToast?.('Código reenviado');
      startCooldown(resend, result.sentAt);
    } else if (result.code === 'cooldown') {
      startCooldown(resend, Date.now() - (RESEND_COOLDOWN_MS - result.waitMs));
    } else if (result.code === 'no-pending') {
      replaceRoute('/recuperar');
    } else {
      triggerHaptic('error');
      setBanner(root, errorMessage(result.code));
      startCooldown(resend, pending.sentAt);
    }
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    setBanner(root, '');
    setFieldError(root, 'code', '');

    if (!validateCode(codeInput.value)) {
      setFieldError(root, 'code', 'Introduz os 4 dígitos do código.');
      codeInput.focus();
      return;
    }

    beginLoading(submit, 'A verificar...');
    let result;
    try {
      result = await withMinDelay(verifyResetCode(codeInput.value));
    } catch {
      result = { ok: false, code: 'storage-failed' };
    }
    endLoading(submit);

    if (!result.ok) {
      triggerHaptic('error');
      submit.disabled = false;
      if (result.code === 'invalid-code') {
        setFieldError(root, 'code', 'Código incorreto. Tenta novamente.');
        codeInput.value = '';
        codeInput.focus();
      } else if (result.code === 'too-many-attempts') {
        setBanner(root, errorMessage(result.code), { hash: '/recuperar', label: 'Pedir novo código' });
        codeInput.disabled = true;
        submit.disabled = true;
        if (resend) resend.disabled = true;
      } else if (result.code === 'no-pending') {
        replaceRoute('/recuperar');
      } else {
        setBanner(root, errorMessage(result.code));
      }
      return;
    }

    triggerHaptic('success');
    navigate('/recuperar/nova-palavra-passe');
  });

  startCooldown(resend, pending.sentAt);
  refresh();
}

function initResetPassword(root) {
  const pending = getPendingAuth();
  if (!pending || pending.kind !== 'reset') {
    replaceRoute('/recuperar');
    return;
  }
  if (!pending.verified) {
    replaceRoute('/recuperar/codigo');
    return;
  }

  const form = root.querySelector('#form-reset');
  const passwordInput = root.querySelector('#auth-password');
  const confirmInput = root.querySelector('#auth-confirm');
  const submit = root.querySelector('[data-submit]');
  if (!form || !passwordInput || !confirmInput || !submit) return;

  const refresh = () => {
    updatePasswordRules(root, passwordInput.value);
    const passwordOk = isPasswordValid(passwordInput.value);
    const matches = validateConfirmation(passwordInput.value, confirmInput.value);
    if (passwordOk) setFieldError(root, 'password', '');
    if (matches || !confirmInput.value) setFieldError(root, 'confirm', '');
    submit.disabled = !(passwordOk && confirmInput.value && matches);
  };

  form.addEventListener('input', refresh);

  confirmInput.addEventListener('blur', () => {
    if (confirmInput.value && !validateConfirmation(passwordInput.value, confirmInput.value)) {
      setFieldError(root, 'confirm', 'As palavras-passe não coincidem.');
    }
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    setBanner(root, '');
    clearFieldErrors(root);

    if (!isPasswordValid(passwordInput.value)) {
      setFieldError(root, 'password', errorMessage('password-weak'));
      updatePasswordRules(root, passwordInput.value);
      passwordInput.focus();
      triggerHaptic('error');
      return;
    }
    if (!validateConfirmation(passwordInput.value, confirmInput.value)) {
      setFieldError(root, 'confirm', 'As palavras-passe não coincidem.');
      confirmInput.focus();
      triggerHaptic('error');
      return;
    }

    beginLoading(submit, 'A guardar...');
    let result;
    try {
      result = await withMinDelay(resetVerifiedPassword(passwordInput.value));
    } catch {
      result = { ok: false, code: 'storage-failed' };
    }
    endLoading(submit);

    if (!result.ok) {
      triggerHaptic('error');
      submit.disabled = false;
      if (result.code === 'not-verified') {
        replaceRoute('/recuperar/codigo');
      } else if (result.code === 'no-pending') {
        replaceRoute('/recuperar');
      } else {
        setBanner(root, errorMessage(result.code));
      }
      return;
    }

    try {
      getStorage('session')?.setItem(LOGIN_EMAIL_KEY, pending.email);
    } catch {
      /* login sem pré-preenchimento */
    }
    triggerHaptic('success');
    renderSuccess(root, {
      title: 'Palavra-passe atualizada',
      message: 'Já podes entrar na tua conta com a nova palavra-passe.',
      action: { hash: '/entrar', label: 'Entrar' }
    });
  });

  refresh();
}
