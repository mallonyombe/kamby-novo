import { getCart, getCartGroupedByStore, getStoreCart, updateQty, removeFromCart, getCartCount, generateWhatsAppOrderUrl } from '../cart.js';
import { getUser } from '../auth.js';
import { ICONS, triggerHaptic } from '../ui.js';

function cartKey(group) {
  return group.storeId ? String(group.storeId) : encodeURIComponent(group.storeName);
}

function decodeCartKey(value) {
  const raw = String(value ?? '');
  return /%[0-9A-Fa-f]{2}/.test(raw) ? decodeURIComponent(raw) : raw;
}

export function renderCartOverview() {
  const groups = getCartGroupedByStore();
  const totalCount = getCartCount();

  if (groups.length === 0) {
    return `
      <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 55vh; text-align: center; padding: 0 var(--k-space-5);">
        <div style="width: 72px; height: 72px; border-radius: 50%; background: var(--k-surface-1); border: 1px solid var(--k-border-subtle); display: grid; place-content: center; margin-bottom: 16px; color: var(--k-ink-2);">
          ${ICONS.cart}
        </div>
        <h2 style="font-size: 18px; font-weight: 700; margin-bottom: 6px;">O teu carrinho está vazio</h2>
        <p style="color: var(--k-ink-2); font-size: 13.5px; margin-bottom: 20px; max-width: 250px; line-height: 1.4;">
          Explora os produtos das lojas locais e adiciona artigos.
        </p>
        <button onclick="window.location.hash = '#/'" class="k-btn-primary" style="width: auto; padding: 0 24px; height: 44px;">
          Explorar produtos
        </button>
      </div>
    `;
  }

  const cardsHTML = groups.map(g => `
    <div class="cart-store-card" onclick="window.location.hash = '#/carrinho/${cartKey(g)}'" role="button" tabindex="0" aria-label="Carrinho de ${g.storeName}">
      <div class="cart-store-head">
        <div>
          <div class="cart-store-name">${g.storeName}</div>
          <div class="cart-store-loc">${g.storeArea}</div>
        </div>
        ${ICONS.chevronRight}
      </div>
      <div class="cart-store-body">
        ${g.items[0]?.img
          ? `<span class="k-img-shell cart-store-thumb-shell" data-fallback="icon">
               <img src="${g.items[0].img}" class="cart-store-thumb" alt="${g.storeName}" data-skel>
             </span>`
          : `<span class="k-img-shell cart-store-thumb-shell" data-fallback="icon" data-loaded="true" data-error="true" aria-hidden="true"></span>`}
        <div class="cart-store-values">
          <span class="cart-store-count">${g.count} artigo${g.count > 1 ? 's' : ''}</span>
          <span class="cart-store-total">${g.total.toLocaleString('pt-MZ')} MT</span>
        </div>
      </div>
    </div>
  `).join('');

  return `
    <div class="cart-overview-container">
      <p class="cart-overview-sub">${totalCount} artigo${totalCount > 1 ? 's' : ''} em ${groups.length} loja${groups.length > 1 ? 's' : ''}</p>
      ${cardsHTML}
    </div>
  `;
}

export function renderStoreCart(storeKey) {
  const group = getStoreCart(decodeCartKey(storeKey));

  if (!group || group.items.length === 0) {
    return `
      <div style="padding: 40px var(--k-space-5); text-align: center;">
        <p style="color: var(--k-ink-2); margin-bottom: 16px;">Não há artigos desta loja no carrinho.</p>
        <button onclick="window.location.hash = '#/carrinho'" class="k-btn-primary" style="height: 44px;">Ver outros carrinhos</button>
      </div>
    `;
  }

  const itemsHTML = group.items.map(item => `
    <div class="cart-item-row" id="item-${item.id}">
      <span class="k-img-shell cart-item-img-shell" data-fallback="icon">
        <img src="${item.img}" class="cart-item-img" alt="${item.name}" data-skel>
      </span>
      <div class="cart-item-info">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-variant">${item.variant.label}</div>
        <div class="cart-item-price" data-line-price>${(item.price * item.qty).toLocaleString('pt-MZ')} MT</div>
      </div>
      <div class="cart-item-actions">
        <button class="cart-item-remove" onclick="window.removeCartItem('${item.id}')" aria-label="Remover artigo">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
        </button>
        <div class="k-stepper">
          <button data-qty-minus onclick="window.changeCartQty('${item.id}', -1)" aria-label="Diminuir quantidade" ${item.qty <= 1 ? 'disabled' : ''}>−</button>
          <span data-qty>${item.qty}</span>
          <button onclick="window.changeCartQty('${item.id}', 1)" aria-label="Aumentar quantidade">+</button>
        </div>
      </div>
    </div>
  `).join('');

  return `
    <div class="store-cart-container" style="padding-bottom: 90px;">
      <div style="margin-bottom: 16px;">
        <h2 style="font-size: 20px; font-weight: 800;">${group.storeName}</h2>
        <div style="font-size: 13px; color: var(--k-ink-2); margin-top: 2px;">${group.storeArea}</div>
      </div>
      
      <div class="store-cart-items">${itemsHTML}</div>
    </div>

    <div class="store-cart-footer">
      <div class="store-cart-footer-info">
        <span class="label">Total</span>
        <span class="num" data-cart-total>${group.total.toLocaleString('pt-MZ')} MT</span>
      </div>
      <button class="k-btn-whatsapp" onclick="window.checkoutWhatsApp('${cartKey(group)}')">
        ${ICONS.whatsapp}
        <span>Finalizar no WhatsApp</span>
      </button>
    </div>
  `;
}

export function initCart() {
  window.changeCartQty = (id, delta) => {
    if (!updateQty(id, delta)) return;
    triggerHaptic('light');

    const item = getCart().find((entry) => entry.id === id);
    if (!item) return;

    const row = document.getElementById(`item-${id}`);
    if (row) {
      const qtyEl = row.querySelector('[data-qty]');
      const lineEl = row.querySelector('[data-line-price]');
      const minusBtn = row.querySelector('[data-qty-minus]');
      if (qtyEl) qtyEl.textContent = item.qty;
      if (lineEl) lineEl.textContent = `${(item.price * item.qty).toLocaleString('pt-MZ')} MT`;
      if (minusBtn) minusBtn.disabled = item.qty <= 1;
    }

    const totalEl = document.querySelector('.store-cart-footer [data-cart-total]');
    const group = getStoreCart(item.storeId);
    if (totalEl && group) totalEl.textContent = `${group.total.toLocaleString('pt-MZ')} MT`;
  };

  window.removeCartItem = (id) => {
    triggerHaptic('medium');
    removeFromCart(id);
    import('../app.js').then(m => m.reRoute());
  };

  window.checkoutWhatsApp = (storeKey) => {
    triggerHaptic('success');
    const group = getStoreCart(decodeCartKey(storeKey));
    if (!group) return;

    const user = getUser();
    const url = generateWhatsAppOrderUrl(group, user);
    window.open(url, '_blank', 'noopener');
  };
}
