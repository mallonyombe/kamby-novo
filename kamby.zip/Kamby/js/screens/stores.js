import { STORES } from '../data.js';
import { triggerHaptic } from '../ui.js';

export function renderStores() {
  const listHTML = STORES.map(s => `
    <div class="store-item-row" onclick="window.navigateToStore(${s.id})" role="button" tabindex="0">
      <span class="k-img-shell store-item-thumb-shell">
        <img src="${s.avatar}" class="store-item-thumb" alt="${s.name}" loading="lazy" data-skel>
      </span>
      <div class="store-item-content">
        <div class="store-item-name">${s.name}</div>
        <div class="store-item-area">${s.area}</div>
      </div>
      <svg class="store-item-arrow" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M9 18l6-6-6-6"/></svg>
    </div>
  `).join('');

  return `
    <div style="padding: 0 var(--k-space-5);">
      <div style="display: flex; flex-direction: column; gap: 10px;">
        ${listHTML}
      </div>
    </div>
  `;
}

window.navigateToStore = (storeId) => {
  triggerHaptic('light');
  window.location.hash = `#/loja/${storeId}`;
};