import { CATEGORIES, PRODUCTS } from '../data.js';
import { triggerHaptic } from '../ui.js';
import { renderProductCard } from '../components/product-card.js';

let activeCategory = "Todos";

function filteredProducts(category) {
  return category === "Todos"
    ? PRODUCTS
    : PRODUCTS.filter((product) => product.category === category);
}

export function renderHome() {
  const categoriesHTML = CATEGORIES.map(c => `
    <button class="k-cat-btn" data-cat="${c}" aria-selected="${c === activeCategory}">
      ${c}
    </button>
  `).join('');

  const productsHTML = filteredProducts(activeCategory).map((product) => renderProductCard(product)).join('');

  return `
    <div class="k-hero" role="region" aria-label="Kamby Express">
      <div class="k-hero-content">
        <span class="k-hero-tag">Kamby Express</span>
        <div class="k-hero-title">Entrega rápida<br>no mesmo dia.</div>
        <div class="k-hero-sub">Produtos locais entregues à tua porta em Chongoene e Maputo.</div>
      </div>
    </div>

    <div class="k-categories" id="home-categories" role="tablist" aria-label="Categorias">
      ${categoriesHTML}
    </div>

    <div class="k-grid" id="home-products-grid" aria-live="polite">
      ${productsHTML}
    </div>
  `;
}

export function initHome() {
  const catBtns = document.querySelectorAll('#home-categories .k-cat-btn');
  const grid = document.getElementById('home-products-grid');

  catBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      triggerHaptic('light');
      activeCategory = btn.dataset.cat || 'Todos';
      catBtns.forEach(b => b.setAttribute('aria-selected', String(b === btn)));
      if (grid) grid.innerHTML = filteredProducts(activeCategory).map((product) => renderProductCard(product)).join('');
    });
  });
}
