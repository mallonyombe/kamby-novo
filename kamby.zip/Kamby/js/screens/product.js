import { getProductDetail, PRODUCTS } from '../data.js';
import { ICONS, triggerHaptic } from '../ui.js';
import { generateWhatsAppOrderUrl } from '../cart.js';
import { getUser } from '../auth.js';
import { isFavorite, toggleFavorite } from '../favorites.js';
import { renderProductCard } from '../components/product-card.js';

function notFound() {
  return `<div class="k-empty-note" style="padding: 40px var(--k-space-5); text-align:center;">
    <p style="color: var(--k-ink-2); margin-bottom: 16px;">Artigo não encontrado.</p>
    <button onclick="window.location.hash = '#/'" class="k-btn-primary" style="height: 44px; width: auto; padding: 0 24px;">Voltar ao início</button>
  </div>`;
}

export function renderPDP(productId) {
  const data = getProductDetail(productId);
  if (!data) return notFound();

  const selectedVariant = data.variants.find(v => v.stock > 0) || data.variants[0];

  const galleryHTML = data.images.map((img, i) => `
    <div class="pdp-gallery-slide k-img-shell" data-fallback="icon">
      <img src="${img}" class="pdp-gallery-img" alt="${data.name}" data-index="${i}" data-skel onclick="window.openProductGallery(${i})">
    </div>
  `).join('');

  const dotsHTML = data.images.map((_, i) => `
    <div class="pdp-dot" data-active="${i === 0}" data-dot="${i}"></div>
  `).join('');

  const variantsHTML = data.variants.map((v) => `
    <button class="pdp-variant-btn" data-variant="${v.id}" ${v.stock === 0 ? 'disabled' : ''} aria-selected="${v.id === selectedVariant.id}">
      ${v.label} ${v.stock === 0 ? '(Esgotado)' : ''}
    </button>
  `).join('');

  const favoriteActive = isFavorite(data.id);

  return `
    <div class="pdp-top-actions">
      <button class="pdp-icon-btn" onclick="window.history.back()" aria-label="Voltar">
        ${ICONS.back}
      </button>
      <div style="display: flex; gap: 8px;">
        <button class="pdp-icon-btn" id="btn-heart" data-active="${favoriteActive}" aria-pressed="${favoriteActive}" aria-label="${favoriteActive ? 'Remover dos favoritos' : 'Adicionar aos favoritos'}">
          ${ICONS.heart}
        </button>
        <button class="pdp-icon-btn" onclick="window.location.hash = '#/carrinho'" aria-label="Abrir carrinho">
          ${ICONS.cart}
        </button>
      </div>
    </div>

    <div class="pdp-gallery" id="pdp-gallery">${galleryHTML}</div>
    <div class="pdp-dots">${dotsHTML}</div>

    <div class="pdp-info">
      <h1 class="pdp-title">${data.name}</h1>

      <div class="pdp-price-row">
        <div class="pdp-price" id="pdp-price">${selectedVariant.price.toLocaleString('pt-MZ')} MT</div>
        ${selectedVariant.oldPrice ? `<div class="pdp-old-price" id="pdp-old-price">${selectedVariant.oldPrice.toLocaleString('pt-MZ')} MT</div>` : '<div class="pdp-old-price" id="pdp-old-price" style="display:none;"></div>'}
      </div>

      <div style="font-size: 13px; font-weight: 700; margin-bottom: 8px; color: var(--k-ink-2);">Opções</div>
      <div class="pdp-variants" id="pdp-variants" role="radiogroup" aria-label="Opções">${variantsHTML}</div>

      <div class="pdp-store" onclick="window.location.hash = '#/loja/${data.store.id}'" role="button" tabindex="0" aria-label="Ver loja ${data.store.name}">
        <span class="k-img-shell pdp-store-avatar-shell">
          <img src="${data.store.avatar}" class="pdp-store-img" alt="${data.store.name}" data-skel>
        </span>
        <div class="pdp-store-info">
          <div class="pdp-store-name">${data.store.name}</div>
          <div class="pdp-store-meta">${data.store.area}</div>
        </div>
        ${ICONS.chevronRight}
      </div>

      <h3 style="font-size: 15px; font-weight: 700; margin-bottom: 6px;">Sobre este artigo</h3>
      <p style="font-size: 13.5px; color: var(--k-ink-2); line-height: 1.45; margin-bottom: 28px;">
        ${data.description}
      </p>

      <div style="font-size: 16px; font-weight: 800; margin-bottom: 12px;">Mais destaques</div>
      <div class="k-hscroll" style="margin: 0 calc(-1 * var(--k-space-5)); padding: 0 var(--k-space-5) 24px;">
        ${PRODUCTS
          .filter((product) => product.id !== data.id)
          .map((product) => renderProductCard(product, {
            showFlag: false,
            showPromoBadge: false,
            showOldPrice: false
          }))
          .join('')}
      </div>
    </div>

    <div class="pdp-footer">
      <button class="k-btn-primary" onclick="window.openCartSheet(${data.id})">Adicionar</button>
      <button class="k-btn-whatsapp" onclick="window.quickBuyWhatsApp()">
        ${ICONS.whatsapp}
        <span>Comprar Já</span>
      </button>
    </div>
  `;
}

export function initPDP(productId) {
  const data = getProductDetail(productId);
  if (!data) {
    window.openProductGallery = () => {};
    window.quickBuyWhatsApp = () => window.showToast?.('Artigo indisponível');
    return;
  }

  const gallery = document.getElementById('pdp-gallery');
  const dots = document.querySelectorAll('.pdp-dot');

  if (gallery) {
    gallery.addEventListener('scroll', () => {
      const index = Math.round(gallery.scrollLeft / gallery.clientWidth);
      dots.forEach((dot, i) => dot.setAttribute('data-active', String(i === index)));
    });
  }

  const variantBtns = document.querySelectorAll('.pdp-variant-btn');
  const priceEl = document.getElementById('pdp-price');
  const oldPriceEl = document.getElementById('pdp-old-price');

  variantBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      if (btn.disabled) return;
      variantBtns.forEach(b => b.setAttribute('aria-selected', String(b === btn)));

      const variant = data.variants.find(x => String(x.id) === String(btn.dataset.variant));
      if (variant && priceEl) {
        priceEl.textContent = `${variant.price.toLocaleString('pt-MZ')} MT`;
        if (oldPriceEl) {
          if (variant.oldPrice) {
            oldPriceEl.textContent = `${variant.oldPrice.toLocaleString('pt-MZ')} MT`;
            oldPriceEl.style.display = 'block';
          } else {
            oldPriceEl.style.display = 'none';
          }
        }
      }
      triggerHaptic('light');
    });
  });

  const heartBtn = document.getElementById('btn-heart');
  if (heartBtn) {
    heartBtn.addEventListener('click', () => {
      const active = toggleFavorite(data.id);
      heartBtn.setAttribute('data-active', String(active));
      heartBtn.setAttribute('aria-pressed', String(active));
      heartBtn.setAttribute('aria-label', active ? 'Remover dos favoritos' : 'Adicionar aos favoritos');
      window.showToast?.(active ? 'Adicionado aos favoritos' : 'Removido dos favoritos');
      triggerHaptic('medium');
    });
  }

  window.openProductGallery = (index) => {
    window.openLightbox(data.images, index);
  };

  window.quickBuyWhatsApp = () => {
    const activeBtn = document.querySelector('.pdp-variant-btn[aria-selected="true"]');
    const variantId = activeBtn ? activeBtn.dataset.variant : data.variants[0].id;
    const variant = data.variants.find(v => String(v.id) === String(variantId)) || data.variants[0];

    const singleItemCart = {
      storeName: data.store.name,
      storeArea: data.store.area,
      storePhone: data.store.whatsapp,
      items: [{
        name: data.name,
        qty: 1,
        price: variant.price,
        variant: { label: variant.label }
      }],
      total: variant.price
    };

    const user = getUser();
    const url = generateWhatsAppOrderUrl(singleItemCart, user);
    triggerHaptic('success');
    window.open(url, '_blank', 'noopener');
  };
}
