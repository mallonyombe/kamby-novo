import { getStoreById, getStoreProducts } from '../data.js';
import { ICONS } from '../ui.js';
import { getStoreCart } from '../cart.js';
import { renderProductCard } from '../components/product-card.js';

let currentStore = null;
let currentSort = 'recent';

function sortProducts(items, sort) {
  const sorted = [...items];
  if (sort === 'price-asc') return sorted.sort((a, b) => a.price - b.price);
  if (sort === 'price-desc') return sorted.sort((a, b) => b.price - a.price);
  return sorted.sort((a, b) => b.id - a.id);
}

function productsHTML(products) {
  if (products.length === 0) {
    return `<div class="k-empty-note">Esta loja ainda não tem artigos publicados.</div>`;
  }
  return products
    .map((product) => renderProductCard(product, { showPromoBadge: false, showOldPrice: false }))
    .join('');
}

window.addEventListener('kamby-sort-apply', (event) => {
  if (event.detail?.context !== 'store') return;
  const grid = document.getElementById('store-products-grid');
  if (!grid || !currentStore) return;
  currentSort = event.detail.sort || 'recent';
  const sorted = sortProducts(getStoreProducts(currentStore.id), currentSort);
  grid.innerHTML = productsHTML(sorted);
  const counter = document.getElementById('store-products-count');
  if (counter) counter.textContent = `${sorted.length}`;
});

export function renderStore(storeId) {
  const store = getStoreById(storeId);
  if (!store) {
    return `<div class="k-empty-note" style="padding: 40px var(--k-space-5);">Loja não encontrada. <button class="k-btn-primary" style="margin-top:16px;height:44px;" onclick="window.location.hash = '#/lojas'">Ver lojas</button></div>`;
  }

  currentStore = store;
  const baseProducts = getStoreProducts(store.id);
  const sortedProducts = sortProducts(baseProducts, currentSort);
  const storeCart = getStoreCart(store.id);
  const cartCount = storeCart ? storeCart.count : 0;

  return `
    <div class="pdp-top-actions">
      <button class="pdp-icon-btn" onclick="window.history.back()" aria-label="Voltar">${ICONS.back}</button>
      <button class="pdp-icon-btn" onclick="window.location.hash = '#/carrinho/${store.id}'" aria-label="Carrinho da loja" style="position: relative;">
        ${ICONS.cart}
        ${cartCount > 0 ? `<span class="k-badge" style="top: -2px; right: -2px;">${cartCount}</span>` : ''}
      </button>
    </div>

    <div class="store-cover-wrapper k-img-shell" data-fallback="icon">
      <img src="${store.cover}" class="store-cover" alt="Capa de ${store.name}" data-skel onclick="window.openLightbox(['${store.cover}'])">
    </div>

    <div class="store-header-info">
      <span class="k-img-shell store-avatar-shell">
        <img src="${store.avatar}" class="store-avatar" alt="${store.name}" data-skel onclick="window.openLightbox(['${store.avatar}'])">
      </span>
      <div class="store-name-row">
        <h1>${store.name}</h1>
      </div>
      <div class="store-meta">${store.area}</div>
      <p class="store-desc">${store.desc}</p>

      <a href="https://wa.me/${store.whatsapp}?text=${encodeURIComponent('Olá! Encontrei a vossa loja no Kamby e gostaria de falar.')}" target="_blank" rel="noopener" class="k-btn-whatsapp" style="margin-top: 14px; height: 42px; font-size: 13.5px;">
        ${ICONS.whatsapp}
        <span>Contactar Loja</span>
      </a>
    </div>

    <div style="display: flex; justify-content: space-between; align-items: center; padding: 0 var(--k-space-5) var(--k-space-4);">
      <div style="font-size: 14.5px; font-weight: 700;">Artigos (<span id="store-products-count">${sortedProducts.length}</span>)</div>
      <button onclick="window.openFilterSheet('store', '${currentSort}')" style="display: inline-flex; align-items: center; gap: 6px; font-size: 13px; color: var(--k-ink-2); font-weight: 600; padding: 6px 12px; background: var(--k-surface-1); border: 1px solid var(--k-border-subtle); border-radius: var(--k-radius-full);" aria-label="Filtrar e ordenar artigos">
        ${ICONS.filter}
        <span>Filtrar</span>
      </button>
    </div>

    <div class="k-grid" id="store-products-grid" style="padding-bottom: 40px;" aria-live="polite">
      ${productsHTML(sortedProducts)}
    </div>
  `;
}
