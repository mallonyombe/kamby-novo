import { changePassword, getUser } from '../auth.js';
import {
  PASSWORD_MAX,
  isPasswordValid,
  validateConfirmation,
  validatePassword
} from '../auth-rules.js';
import { ICONS, triggerHaptic } from '../ui.js';
import {
  beginLoading,
  bindPasswordToggles,
  endLoading,
  renderPasswordChecklist,
  renderTextField,
  setBanner,
  setFieldError,
  updatePasswordChecklist
} from '../components/form.js';

function errorMessage(code) {
  const messages = {
    'invalid-current-password': 'A palavra-passe atual não está correta.',
    'password-weak': 'A palavra-passe não cumpre os requisitos.',
    'same-password': 'A nova palavra-passe tem de ser diferente da atual.',
    'storage-failed': 'Não foi possível guardar a nova palavra-passe neste dispositivo.',
    'no-session': 'A tua sessão expirou. Entra novamente.',
    'not-supported': 'Esta conta não permite alterar a palavra-passe.'
  };
  return messages[code] || 'Não foi possível alterar a palavra-passe. Tenta novamente.';
}

export function renderSecurity() {
  const user = getUser();
  if (!user) return '';

  return `
    <div class="settings-screen">
      <div class="settings-hero">
        <div class="settings-hero-icon" aria-hidden="true">${ICONS.shieldCheck}</div>
        <div>
          <span class="settings-eyebrow">Segurança da conta</span>
          <h1>Altera a palavra-passe</h1>
          <p>Confirma a tua chave atual e escolhe uma nova para manter a sessão protegida.</p>
        </div>
      </div>

      <form class="settings-form" id="form-account-security" novalidate>
        <p class="auth-banner" data-banner role="alert" tabindex="-1" hidden></p>

        <div class="settings-card">
          ${renderTextField({
            name: 'currentPassword',
            label: 'Palavra-passe atual',
            type: 'password',
            autocomplete: 'current-password',
            toggle: true,
            enter: 'next',
            maxlength: PASSWORD_MAX,
            inputAttrs: 'autocapitalize="none" spellcheck="false"'
          })}

          ${renderTextField({
            name: 'newPassword',
            label: 'Nova palavra-passe',
            type: 'password',
            autocomplete: 'new-password',
            toggle: true,
            enter: 'next',
            maxlength: PASSWORD_MAX,
            inputAttrs: 'autocapitalize="none" spellcheck="false"'
          })}

          ${renderPasswordChecklist()}

          ${renderTextField({
            name: 'confirmPassword',
            label: 'Confirmar nova palavra-passe',
            type: 'password',
            autocomplete: 'new-password',
            toggle: true,
            enter: 'done',
            maxlength: PASSWORD_MAX,
            inputAttrs: 'autocapitalize="none" spellcheck="false"'
          })}
        </div>

        <p class="settings-security-note">${ICONS.shieldCheck}<span>A sessão atual mantém-se nesta conta depois da alteração.</span></p>

        <div class="settings-actions">
          <button type="submit" class="k-btn-primary" data-submit disabled>Alterar palavra-passe</button>
        </div>
      </form>
    </div>
  `;
}

export function initSecurity() {
  const root = document.getElementById('app-view');
  const form = document.getElementById('form-account-security');
  const currentInput = document.getElementById('field-currentPassword');
  const newInput = document.getElementById('field-newPassword');
  const confirmInput = document.getElementById('field-confirmPassword');
  const submit = form?.querySelector('[data-submit]');
  if (!root || !form || !currentInput || !newInput || !confirmInput || !submit) return;

  bindPasswordToggles(root);

  const refresh = () => {
    updatePasswordChecklist(root, newInput.value);
    submit.disabled = !currentInput.value
      || !isPasswordValid(newInput.value)
      || newInput.value !== confirmInput.value;

    if (isPasswordValid(newInput.value)) setFieldError(root, 'newPassword', '');
    if (confirmInput.value && newInput.value === confirmInput.value) {
      setFieldError(root, 'confirmPassword', '');
    }
  };

  currentInput.addEventListener('input', () => {
    if (currentInput.value) setFieldError(root, 'currentPassword', '');
    refresh();
  });

  newInput.addEventListener('input', refresh);

  confirmInput.addEventListener('input', refresh);
  confirmInput.addEventListener('blur', () => {
    if (!confirmInput.value) return;
    setFieldError(
      root,
      'confirmPassword',
      validateConfirmation(newInput.value, confirmInput.value)
        ? ''
        : 'As palavras-passe não coincidem.'
    );
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (submit.disabled) return;

    setBanner(root, '');
    setFieldError(root, 'currentPassword', '');
    setFieldError(root, 'newPassword', '');
    setFieldError(root, 'confirmPassword', '');

    if (!currentInput.value) {
      setFieldError(root, 'currentPassword', 'Introduz a palavra-passe atual.');
      currentInput.focus();
      return;
    }

    const passwordCheck = validatePassword(newInput.value);
    if (!passwordCheck.ok) {
      setFieldError(root, 'newPassword', 'A palavra-passe não cumpre os requisitos.');
      newInput.focus();
      return;
    }

    if (!validateConfirmation(newInput.value, confirmInput.value)) {
      setFieldError(root, 'confirmPassword', 'As palavras-passe não coincidem.');
      confirmInput.focus();
      return;
    }

    beginLoading(submit, 'A alterar...');
    await new Promise((resolve) => setTimeout(resolve, 450));
    if (!document.body.contains(form)) return;

    let result;
    try {
      result = await changePassword(currentInput.value, newInput.value);
    } catch {
      result = { ok: false, code: 'storage-failed' };
    }

    if (!result.ok) {
      endLoading(submit);
      triggerHaptic('error');

      if (result.code === 'invalid-current-password') {
        setFieldError(root, 'currentPassword', errorMessage(result.code));
        currentInput.focus();
      } else if (result.code === 'same-password') {
        setFieldError(root, 'newPassword', errorMessage(result.code));
        newInput.focus();
      } else {
        setBanner(root, errorMessage(result.code));
      }
      return;
    }

    triggerHaptic('success');
    window.showToast?.('Palavra-passe atualizada');
    window.location.hash = '#/perfil';
  });

  refresh();
}
