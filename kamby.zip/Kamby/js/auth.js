import {
  normalizeCode,
  normalizeEmail,
  normalizePassword,
  normalizeSex,
  validateCode,
  validateEmail,
  validateName,
  validatePassword
} from './auth-rules.js';

const ACCOUNTS_KEY = 'kamby_accounts';
const SESSION_KEY = 'kamby_user';
const PENDING_KEY = 'kamby_auth_pending';

const SECURE_ITERATIONS = 600000;
const FALLBACK_ITERATIONS = 10000;
const MAX_CODE_ATTEMPTS = 5;

export const DEMO_VERIFICATION_CODE = '1234';
export const RESEND_COOLDOWN_MS = 30000;

let user = readJSON(getLocalStorage(), SESSION_KEY, null);
let memoryPending = null;

/* ── PERSISTÊNCIA ── */
function getLocalStorage() {
  try {
    return globalThis.localStorage || null;
  } catch {
    return null;
  }
}

function getSessionStorage() {
  try {
    return globalThis.sessionStorage || null;
  } catch {
    return null;
  }
}

function readJSON(storage, key, fallback) {
  if (!storage) return fallback;
  try {
    const raw = storage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function writeJSON(storage, key, value) {
  if (!storage) return false;
  try {
    storage.setItem(key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}

function readAccounts() {
  const accounts = readJSON(getLocalStorage(), ACCOUNTS_KEY, []);
  return Array.isArray(accounts) ? accounts : [];
}

function saveAccounts(accounts) {
  return writeJSON(getLocalStorage(), ACCOUNTS_KEY, accounts);
}

function readPending() {
  if (memoryPending) return memoryPending;
  const pending = readJSON(getSessionStorage(), PENDING_KEY, null);
  return pending && typeof pending === 'object' ? pending : null;
}

function savePending(pending) {
  memoryPending = pending;
  return writeJSON(getSessionStorage(), PENDING_KEY, pending);
}

function clearPending() {
  memoryPending = null;
  try {
    getSessionStorage()?.removeItem(PENDING_KEY);
  } catch {
    /* demo: memória mantém o estado durante a sessão */
  }
}

function emitAuthChanged() {
  if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
    window.dispatchEvent(new Event('auth-changed'));
  }
}

function commitSession(nextUser) {
  user = nextUser;
  const storage = getLocalStorage();
  try {
    if (nextUser) storage?.setItem(SESSION_KEY, JSON.stringify(nextUser));
    else storage?.removeItem(SESSION_KEY);
  } catch {
    /* sessão em memória continua válida nesta aba */
  }
  emitAuthChanged();
}

function toSession(account) {
  const createdAt = account.createdAt || new Date().toISOString();
  return {
    id: account.id,
    name: account.name,
    email: account.email,
    sex: account.sex || null,
    phone: account.phone || null,
    avatar: null,
    createdAt,
    memberSince: String(new Date(createdAt).getFullYear() || '')
  };
}

function createId() {
  try {
    if (globalThis.crypto?.randomUUID) return `usr_${globalThis.crypto.randomUUID()}`;
  } catch {
    /* fallback abaixo */
  }
  return `usr_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

/* ── HASHING DEMO (PBKDF2 Web Crypto + fallback para LAN HTTP) ── */
const SHA256_K = new Uint32Array([
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
]);

function rotateRight(value, shift) {
  return (value >>> shift) | (value << (32 - shift));
}

function sha256(bytes) {
  const length = bytes.length;
  const bitLength = length * 8;
  const paddedLength = Math.ceil((length + 9) / 64) * 64;
  const message = new Uint8Array(paddedLength);
  message.set(bytes);
  message[length] = 0x80;

  const view = new DataView(message.buffer);
  view.setUint32(paddedLength - 8, Math.floor(bitLength / 0x100000000), false);
  view.setUint32(paddedLength - 4, bitLength >>> 0, false);

  const hash = new Uint32Array([
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
  ]);
  const schedule = new Uint32Array(64);

  for (let offset = 0; offset < paddedLength; offset += 64) {
    for (let index = 0; index < 16; index += 1) {
      schedule[index] = view.getUint32(offset + index * 4, false);
    }
    for (let index = 16; index < 64; index += 1) {
      const previous15 = schedule[index - 15];
      const previous2 = schedule[index - 2];
      const sigma0 = rotateRight(previous15, 7) ^ rotateRight(previous15, 18) ^ (previous15 >>> 3);
      const sigma1 = rotateRight(previous2, 17) ^ rotateRight(previous2, 19) ^ (previous2 >>> 10);
      schedule[index] = (schedule[index - 16] + sigma0 + schedule[index - 7] + sigma1) >>> 0;
    }

    let a = hash[0];
    let b = hash[1];
    let c = hash[2];
    let d = hash[3];
    let e = hash[4];
    let f = hash[5];
    let g = hash[6];
    let h = hash[7];

    for (let index = 0; index < 64; index += 1) {
      const sum1 = rotateRight(e, 6) ^ rotateRight(e, 11) ^ rotateRight(e, 25);
      const choice = (e & f) ^ (~e & g);
      const temp1 = (h + sum1 + choice + SHA256_K[index] + schedule[index]) >>> 0;
      const sum0 = rotateRight(a, 2) ^ rotateRight(a, 13) ^ rotateRight(a, 22);
      const majority = (a & b) ^ (a & c) ^ (b & c);
      const temp2 = (sum0 + majority) >>> 0;

      h = g;
      g = f;
      f = e;
      e = (d + temp1) >>> 0;
      d = c;
      c = b;
      b = a;
      a = (temp1 + temp2) >>> 0;
    }

    hash[0] = (hash[0] + a) >>> 0;
    hash[1] = (hash[1] + b) >>> 0;
    hash[2] = (hash[2] + c) >>> 0;
    hash[3] = (hash[3] + d) >>> 0;
    hash[4] = (hash[4] + e) >>> 0;
    hash[5] = (hash[5] + f) >>> 0;
    hash[6] = (hash[6] + g) >>> 0;
    hash[7] = (hash[7] + h) >>> 0;
  }

  const output = new Uint8Array(32);
  const outputView = new DataView(output.buffer);
  hash.forEach((value, index) => outputView.setUint32(index * 4, value, false));
  return output;
}

function bytesToBase64(bytes) {
  let binary = '';
  bytes.forEach((byte) => {
    binary += String.fromCharCode(byte);
  });
  return btoa(binary);
}

function base64ToBytes(value) {
  const binary = atob(value);
  return Uint8Array.from(binary, (char) => char.charCodeAt(0));
}

function createSalt() {
  const salt = new Uint8Array(16);
  try {
    if (globalThis.crypto?.getRandomValues) globalThis.crypto.getRandomValues(salt);
    else throw new Error('getRandomValues indisponível');
  } catch {
    for (let index = 0; index < salt.length; index += 1) {
      salt[index] = Math.floor(Math.random() * 256);
    }
  }
  return salt;
}

function hasSubtleCrypto() {
  return Boolean(
    globalThis.crypto?.subtle
    && typeof globalThis.crypto.subtle.importKey === 'function'
    && typeof globalThis.crypto.subtle.deriveBits === 'function'
  );
}

async function deriveSecure(password, salt, iterations) {
  const encoder = new TextEncoder();
  const keyMaterial = await globalThis.crypto.subtle.importKey(
    'raw',
    encoder.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );
  const bits = await globalThis.crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt,
      iterations,
      hash: 'SHA-256'
    },
    keyMaterial,
    256
  );
  return bytesToBase64(new Uint8Array(bits));
}

function deriveFallback(password, salt) {
  const encoder = new TextEncoder();
  const passwordBytes = encoder.encode(password);
  let digest = sha256(concatBytes(salt, passwordBytes));
  for (let index = 1; index < FALLBACK_ITERATIONS; index += 1) {
    digest = sha256(concatBytes(salt, digest));
  }
  return bytesToBase64(digest);
}

function concatBytes(first, second) {
  const merged = new Uint8Array(first.length + second.length);
  merged.set(first, 0);
  merged.set(second, first.length);
  return merged;
}

async function createCredential(password) {
  const salt = createSalt();
  if (hasSubtleCrypto()) {
    try {
      return {
        algo: 'pbkdf2-sha256',
        iterations: SECURE_ITERATIONS,
        salt: bytesToBase64(salt),
        hash: await deriveSecure(password, salt, SECURE_ITERATIONS)
      };
    } catch {
      /* LAN HTTP / contexto não seguro: usa fallback demo */
    }
  }
  return {
    algo: 'js-sha256-demo',
    iterations: FALLBACK_ITERATIONS,
    salt: bytesToBase64(salt),
    hash: deriveFallback(password, salt)
  };
}

function clampIterations(value, fallback) {
  const iterations = Number(value);
  if (!Number.isFinite(iterations)) return fallback;
  return Math.min(Math.max(Math.floor(iterations), 1), 1000000);
}

async function verifyCredential(password, credential) {
  if (!credential || !credential.salt || !credential.hash) return false;
  const salt = base64ToBytes(credential.salt);

  if (credential.algo === 'pbkdf2-sha256') {
    if (!hasSubtleCrypto()) return false;
    const iterations = clampIterations(credential.iterations, SECURE_ITERATIONS);
    const hash = await deriveSecure(password, salt, iterations);
    return hash === credential.hash;
  }

  if (credential.algo === 'js-sha256-demo') {
    return deriveFallback(password, salt) === credential.hash;
  }

  return false;
}

async function burnPasswordCheck(password) {
  const salt = new Uint8Array(16).fill(7);
  try {
    if (hasSubtleCrypto()) {
      await deriveSecure(password, salt, SECURE_ITERATIONS);
      return;
    }
  } catch {
    /* continua para o fallback */
  }
  deriveFallback(password, salt);
}

/* ── API PÚBLICA DEMO ── */
export function getUser() {
  return user;
}

export function canChangePassword() {
  if (!user?.email) return false;
  const email = normalizeEmail(user.email);
  return readAccounts().some((account) => account.email === email && Boolean(account.credential));
}

export function updateProfile(data) {
  if (!user) return { ok: false, code: 'no-session' };

  const nameCheck = validateName(data?.name);
  if (!nameCheck.ok) return { ok: false, code: nameCheck.code };

  const sex = normalizeSex(data?.sex);
  const accounts = readAccounts();
  const email = user.email ? normalizeEmail(user.email) : '';
  const accountIndex = accounts.findIndex((account) => (
    (user.id && account.id === user.id) || (email && account.email === email)
  ));

  if (accountIndex >= 0) {
    accounts[accountIndex] = {
      ...accounts[accountIndex],
      name: nameCheck.name,
      sex,
      updatedAt: new Date().toISOString()
    };
    if (!saveAccounts(accounts)) return { ok: false, code: 'storage-failed' };
  }

  commitSession({ ...user, name: nameCheck.name, sex });
  return { ok: true, user };
}

export async function changePassword(currentInput, newInput) {
  if (!user) return { ok: false, code: 'no-session' };
  if (!user.email) return { ok: false, code: 'not-supported' };

  const email = normalizeEmail(user.email);
  const accounts = readAccounts();
  const accountIndex = accounts.findIndex((account) => (
    account.email === email || (user.id && account.id === user.id)
  ));

  if (accountIndex < 0 || !accounts[accountIndex].credential) {
    return { ok: false, code: 'not-supported' };
  }

  const currentPassword = normalizePassword(currentInput);
  const currentValid = await verifyCredential(currentPassword, accounts[accountIndex].credential);
  if (!currentValid) return { ok: false, code: 'invalid-current-password' };

  const passwordCheck = validatePassword(newInput);
  if (!passwordCheck.ok) {
    return { ok: false, code: passwordCheck.code, checks: passwordCheck.checks };
  }

  if (await verifyCredential(passwordCheck.password, accounts[accountIndex].credential)) {
    return { ok: false, code: 'same-password' };
  }

  accounts[accountIndex].credential = await createCredential(passwordCheck.password);
  accounts[accountIndex].updatedAt = new Date().toISOString();
  if (!saveAccounts(accounts)) return { ok: false, code: 'storage-failed' };

  return { ok: true };
}

export function getPendingAuth() {
  const pending = readPending();
  if (!pending) return null;
  return {
    kind: pending.kind,
    email: pending.email || '',
    name: pending.name || '',
    sentAt: Number(pending.sentAt) || 0,
    attempts: Number(pending.attempts) || 0,
    verified: pending.verified === true,
    verifiedAt: Number(pending.verifiedAt) || 0
  };
}

export function clearPendingAuth() {
  clearPending();
}

export async function startRegistration(data, password) {
  const nameCheck = validateName(data?.name);
  if (!nameCheck.ok) return { ok: false, code: nameCheck.code };

  const emailCheck = validateEmail(data?.email);
  if (!emailCheck.ok) return { ok: false, code: emailCheck.code };

  const passwordCheck = validatePassword(password);
  if (!passwordCheck.ok) return { ok: false, code: passwordCheck.code };

  if (readAccounts().some((account) => account.email === emailCheck.email)) {
    return { ok: false, code: 'email-exists', email: emailCheck.email };
  }

  const credential = await createCredential(passwordCheck.password);
  const pending = {
    kind: 'verify',
    name: nameCheck.name,
    sex: normalizeSex(data?.sex),
    email: emailCheck.email,
    credential,
    sentAt: Date.now(),
    attempts: 0
  };

  if (!savePending(pending)) return { ok: false, code: 'storage-failed' };
  return { ok: true, email: pending.email, sentAt: pending.sentAt };
}

export async function verifyPendingCode(code) {
  const pending = readPending();
  if (!pending || pending.kind !== 'verify') return { ok: false, code: 'no-pending' };

  const nameCheck = validateName(pending.name);
  const emailCheck = validateEmail(pending.email);
  if (!nameCheck.ok || !emailCheck.ok || !pending.credential) {
    clearPending();
    return { ok: false, code: 'no-pending' };
  }

  const normalizedCode = normalizeCode(code);
  if (!validateCode(normalizedCode)) return { ok: false, code: 'invalid-code' };

  if (normalizedCode !== DEMO_VERIFICATION_CODE) {
    pending.attempts = (Number(pending.attempts) || 0) + 1;
    if (pending.attempts >= MAX_CODE_ATTEMPTS) {
      clearPending();
      return { ok: false, code: 'too-many-attempts' };
    }
    savePending(pending);
    return { ok: false, code: 'invalid-code', attemptsLeft: MAX_CODE_ATTEMPTS - pending.attempts };
  }

  const accounts = readAccounts();
  if (accounts.some((account) => account.email === emailCheck.email)) {
    clearPending();
    return { ok: false, code: 'email-exists' };
  }

  const account = {
    id: createId(),
    name: nameCheck.name,
    sex: normalizeSex(pending.sex),
    email: emailCheck.email,
    credential: pending.credential,
    verified: true,
    createdAt: new Date().toISOString()
  };
  accounts.push(account);

  if (!saveAccounts(accounts)) return { ok: false, code: 'storage-failed' };

  clearPending();
  const session = toSession(account);
  commitSession(session);
  return { ok: true, user: session };
}

export async function resendCode() {
  const pending = readPending();
  if (!pending) return { ok: false, code: 'no-pending' };

  const elapsed = Date.now() - (Number(pending.sentAt) || 0);
  const waitMs = RESEND_COOLDOWN_MS - elapsed;
  if (waitMs > 0) return { ok: false, code: 'cooldown', waitMs };

  pending.sentAt = Date.now();
  pending.verified = false;
  if (!savePending(pending)) return { ok: false, code: 'storage-failed' };
  return { ok: true, sentAt: pending.sentAt, waitMs: RESEND_COOLDOWN_MS };
}

export async function login(emailInput, passwordInput) {
  const emailCheck = validateEmail(emailInput);
  const password = normalizePassword(passwordInput);
  const accounts = readAccounts();
  const account = emailCheck.ok
    ? accounts.find((entry) => entry.email === emailCheck.email)
    : null;

  if (!account) {
    await burnPasswordCheck(password || 'kamby');
    return { ok: false, code: 'invalid-credentials' };
  }

  const valid = await verifyCredential(password, account.credential);
  if (!valid) return { ok: false, code: 'invalid-credentials' };

  const session = toSession(account);
  commitSession(session);
  return { ok: true, user: session };
}

export async function requestReset(emailInput) {
  const emailCheck = validateEmail(emailInput);
  if (!emailCheck.ok) return { ok: false, code: emailCheck.code };

  const pending = {
    kind: 'reset',
    email: emailCheck.email,
    sentAt: Date.now(),
    attempts: 0
  };

  if (!savePending(pending)) return { ok: false, code: 'storage-failed' };
  return { ok: true, email: emailCheck.email, sentAt: pending.sentAt };
}

export async function verifyResetCode(codeInput) {
  const pending = readPending();
  if (!pending || pending.kind !== 'reset') return { ok: false, code: 'no-pending' };

  const normalizedCode = normalizeCode(codeInput);
  if (!validateCode(normalizedCode)) return { ok: false, code: 'invalid-code' };

  if (normalizedCode !== DEMO_VERIFICATION_CODE) {
    pending.attempts = (Number(pending.attempts) || 0) + 1;
    pending.verified = false;
    if (pending.attempts >= MAX_CODE_ATTEMPTS) {
      clearPending();
      return { ok: false, code: 'too-many-attempts' };
    }
    savePending(pending);
    return { ok: false, code: 'invalid-code', attemptsLeft: MAX_CODE_ATTEMPTS - pending.attempts };
  }

  pending.verified = true;
  pending.verifiedAt = Date.now();
  pending.attempts = 0;
  if (!savePending(pending)) return { ok: false, code: 'storage-failed' };
  return { ok: true, email: pending.email };
}

export async function resetVerifiedPassword(newPassword) {
  const pending = readPending();
  if (!pending || pending.kind !== 'reset') return { ok: false, code: 'no-pending' };
  if (!pending.verified) return { ok: false, code: 'not-verified' };

  const passwordCheck = validatePassword(newPassword);
  if (!passwordCheck.ok) return { ok: false, code: passwordCheck.code };

  const accounts = readAccounts();
  const accountIndex = accounts.findIndex((account) => account.email === pending.email);

  if (accountIndex >= 0) {
    accounts[accountIndex].credential = await createCredential(passwordCheck.password);
    accounts[accountIndex].updatedAt = new Date().toISOString();
    if (!saveAccounts(accounts)) return { ok: false, code: 'storage-failed' };
  }

  clearPending();
  return { ok: true, email: pending.email };
}

export async function resetPassword(code, newPassword) {
  const verified = await verifyResetCode(code);
  if (!verified.ok) return verified;
  return resetVerifiedPassword(newPassword);
}

export async function deleteAccount() {
  if (!user) return { ok: false, code: 'no-session' };

  if (user.email) {
    const accounts = readAccounts();
    const nextAccounts = accounts.filter((account) => account.email !== normalizeEmail(user.email));
    if (nextAccounts.length !== accounts.length && !saveAccounts(nextAccounts)) {
      return { ok: false, code: 'storage-failed' };
    }
  }

  clearPending();
  logout();
  return { ok: true };
}

export function logout() {
  commitSession(null);
}
