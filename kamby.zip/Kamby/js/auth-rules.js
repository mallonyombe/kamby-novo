const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export const NAME_MIN = 2;
export const NAME_MAX = 80;
export const PASSWORD_MIN = 8;
export const PASSWORD_MAX = 64;
export const CODE_LENGTH = 4;
export const SEX_VALUES = ['female', 'male', 'other', 'undisclosed'];

export const SEX_OPTIONS = [
  { value: null, label: 'Prefiro não dizer' },
  { value: 'female', label: 'Feminino' },
  { value: 'male', label: 'Masculino' },
  { value: 'other', label: 'Outro' }
];

export const SEX_LABELS = {
  female: 'Feminino',
  male: 'Masculino',
  other: 'Outro',
  undisclosed: 'Prefiro não dizer'
};

export function sexLabel(value) {
  return SEX_LABELS[value] || SEX_LABELS.undisclosed;
}

export function normalizeName(value) {
  return String(value || '').replace(/\s+/g, ' ').trim();
}

export function validateName(value) {
  const name = normalizeName(value);
  if (name.length < NAME_MIN) return { ok: false, code: 'name-short', name };
  if (name.length > NAME_MAX) return { ok: false, code: 'name-long', name };
  return { ok: true, name };
}

export function normalizeEmail(value) {
  return String(value || '').trim().toLowerCase();
}

export function validateEmail(value) {
  const email = normalizeEmail(value);
  if (!email) return { ok: false, code: 'email-empty', email };
  if (email.length > 254 || !EMAIL_PATTERN.test(email)) {
    return { ok: false, code: 'email-invalid', email };
  }
  return { ok: true, email };
}

export function normalizePassword(value) {
  return String(value || '').normalize('NFC');
}

export function passwordChecks(value) {
  const password = normalizePassword(value);
  return {
    length: password.length >= PASSWORD_MIN && password.length <= PASSWORD_MAX,
    upper: /[A-Z]/.test(password),
    lower: /[a-z]/.test(password),
    digit: /\d/.test(password)
  };
}

export function isPasswordValid(value) {
  return Object.values(passwordChecks(value)).every(Boolean);
}

export function validatePassword(value) {
  const password = normalizePassword(value);
  const checks = passwordChecks(password);
  if (!isPasswordValid(password)) return { ok: false, code: 'password-weak', password, checks };
  return { ok: true, password, checks };
}

export function validateConfirmation(password, confirmation) {
  return normalizePassword(password) === normalizePassword(confirmation);
}

export function normalizeSex(value) {
  return SEX_VALUES.includes(value) ? value : null;
}

export function validateCode(value) {
  const code = String(value || '').replace(/\s/g, '');
  return new RegExp(`^\\d{${CODE_LENGTH}}$`).test(code);
}

export function normalizeCode(value) {
  return String(value || '').replace(/\D/g, '').slice(0, CODE_LENGTH);
}
