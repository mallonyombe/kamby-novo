import { ICONS, escapeHtml } from '../ui.js';

export function renderProductCard(product, {
  removable = false,
  showFlag = true,
  showPromoBadge = true,
  showOldPrice = true
} = {}) {
  const hasPromo = product.oldPrice !== null
    && product.oldPrice !== undefined
    && product.oldPrice > product.price;
  const discount = hasPromo ? Math.round((1 - product.price / product.oldPrice) * 100) : 0;
  const name = escapeHtml(product.name);
  const id = escapeHtml(String(product.id));

  const card = `
    <a class="k-product-card" href="#/p/${id}" aria-label="${name}">
      <div class="k-product-img-wrap k-img-shell" data-fallback="icon">
        <img src="${escapeHtml(product.img)}" class="k-product-img" alt="${name}" loading="lazy" data-skel>
        ${showFlag && product.flag ? `<span class="k-product-flag">${escapeHtml(product.flag)}</span>` : ''}
        ${showPromoBadge && hasPromo ? `<span class="k-promo-badge">-${discount}%</span>` : ''}
      </div>
      <div class="k-product-title">${name}</div>
      <div class="k-price-wrap">
        <div class="k-product-price">${product.price.toLocaleString('pt-MZ')} <span>MT</span></div>
        ${showOldPrice && hasPromo ? `<div class="k-price-old">${product.oldPrice.toLocaleString('pt-MZ')} MT</div>` : ''}
      </div>
    </a>
  `;

  if (!removable) return card;

  return `
    <div class="k-product-card-wrap">
      ${card}
      <button
        type="button"
        class="k-favorite-remove"
        data-favorite-remove="${id}"
        aria-label="Remover ${name} dos favoritos"
      >
        ${ICONS.heart}
      </button>
    </div>
  `;
}
