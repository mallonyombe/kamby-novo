import { passwordChecks } from '../auth-rules.js';
import { ICONS, escapeHtml } from '../ui.js';

export function renderTextField({
  name,
  label,
  type = 'text',
  autocomplete = 'off',
  inputmode = '',
  placeholder = '',
  value = '',
  maxlength = '',
  optional = false,
  toggle = false,
  enter = 'next',
  inputAttrs = ''
}) {
  const id = `field-${name}`;
  const trailing = toggle
    ? `<button type="button" class="auth-eye" data-toggle-password="${id}" aria-label="Mostrar palavra-passe" aria-pressed="false">${ICONS.eye}</button>`
    : '';

  return `
    <div class="auth-field" data-field="${name}">
      <label for="${id}">
        ${escapeHtml(label)}
        ${optional ? '<span class="auth-optional">(opcional)</span>' : ''}
      </label>
      <div class="auth-input-shell">
        <input
          class="auth-input"
          id="${id}"
          name="${name}"
          type="${type}"
          value="${escapeHtml(value)}"
          placeholder="${escapeHtml(placeholder)}"
          autocomplete="${autocomplete}"
          enterkeyhint="${enter}"
          ${inputmode ? `inputmode="${inputmode}"` : ''}
          ${maxlength ? `maxlength="${maxlength}"` : ''}
          aria-describedby="${id}-error"
          ${inputAttrs}
        >
        ${trailing}
      </div>
      <p class="auth-error" id="${id}-error" aria-live="polite"></p>
    </div>
  `;
}

export function renderPasswordChecklist() {
  const rules = [
    ['length', '8 a 64 caracteres'],
    ['upper', 'Uma maiúscula'],
    ['lower', 'Uma minúscula'],
    ['digit', 'Um número']
  ];

  return `
    <ul class="auth-rules" aria-label="Requisitos da palavra-passe">
      ${rules.map(([key, label]) => `
        <li class="auth-rule" data-check="${key}">
          <span class="auth-rule-icon" aria-hidden="true">${ICONS.check}</span>
          <span>${label}</span>
          <span class="auth-rule-state k-visually-hidden">Não cumprido</span>
        </li>
      `).join('')}
    </ul>
  `;
}

export function updatePasswordChecklist(root, password) {
  const checks = passwordChecks(password);
  root.querySelectorAll('.auth-rule').forEach((rule) => {
    const met = Boolean(checks[rule.dataset.check]);
    rule.dataset.met = String(met);
    const state = rule.querySelector('.auth-rule-state');
    if (state) state.textContent = met ? 'Cumprido' : 'Não cumprido';
  });
}

export function setFieldError(root, name, message = '') {
  const field = root.querySelector(`.auth-field[data-field="${name}"]`);
  if (!field) return;
  const input = field.querySelector('input');
  const error = field.querySelector('.auth-error');
  if (input) {
    if (message) input.setAttribute('aria-invalid', 'true');
    else input.removeAttribute('aria-invalid');
  }
  if (error) error.textContent = message;
}

export function setBanner(root, message = '') {
  const banner = root.querySelector('[data-banner]');
  if (!banner) return;
  banner.hidden = !message;
  banner.textContent = message;
}

export function bindPasswordToggles(root) {
  root.querySelectorAll('[data-toggle-password]').forEach((button) => {
    const input = document.getElementById(button.dataset.togglePassword);
    if (!input) return;
    button.addEventListener('click', () => {
      const showing = input.type === 'text';
      input.type = showing ? 'password' : 'text';
      button.innerHTML = showing ? ICONS.eye : ICONS.eyeOff;
      button.setAttribute('aria-pressed', String(!showing));
      button.setAttribute('aria-label', showing ? 'Mostrar palavra-passe' : 'Ocultar palavra-passe');
      input.focus({ preventScroll: true });
    });
  });
}

export function beginLoading(button, label) {
  if (!button) return;
  button.dataset.idleLabel = button.textContent.trim();
  button.disabled = true;
  button.setAttribute('aria-busy', 'true');
  button.innerHTML = `<span class="k-spinner" aria-hidden="true"></span> ${escapeHtml(label)}`;
}

export function endLoading(button) {
  if (!button) return;
  button.removeAttribute('aria-busy');
  button.textContent = button.dataset.idleLabel || 'Guardar';
  button.disabled = false;
}
