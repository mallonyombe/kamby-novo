export const CATEGORIES = [
  "Todos",
  "Tecnologia",
  "Casa",
  "Moda",
  "Alimentação",
  "Beleza"
];

export const STORES = [
  {
    id: 1,
    name: "Casa & Estilo",
    area: "Chongoene · Centro",
    whatsapp: "258841234567",
    avatar: "https://images.unsplash.com/photo-1526738549149-8e07eca6c147?w=200&q=80",
    cover: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80",
    desc: "Artigos para o lar, tecnologia e utilidades. Entregas expressas no mesmo dia para toda a região."
  },
  {
    id: 2,
    name: "Mercearia do Bairro",
    area: "Chongoene · Bairro da Escola",
    whatsapp: "258849876543",
    avatar: "https://images.unsplash.com/photo-1542838132-92c53300491e?w=200&q=80",
    cover: "https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&q=80",
    desc: "Hortícolas, mercearia e cabazes frescos selecionados no bairro, com entrega rápida porta a porta."
  },
  {
    id: 3,
    name: "Nair Boutique",
    area: "Sommerschield · Maputo",
    whatsapp: "258823456789",
    avatar: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=200&q=80",
    cover: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800&q=80",
    desc: "Boutique de moda e beleza em Maputo com peças selecionadas e curadoria pessoal por WhatsApp."
  }
];

const defaultVariants = (price, oldPrice, stock = 9) => [
  { id: "padrao", label: "Padrão", price, oldPrice, stock }
];

export const PRODUCTS = [
  {
    id: 1,
    name: "Caneca de cerâmica artesanal 500 ml",
    price: 675,
    oldPrice: null,
    flag: "Novo",
    storeId: 1,
    category: "Casa",
    img: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=400&q=80",
    images: [
      "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=800&q=80",
      "https://images.unsplash.com/photo-1610701596007-11502861dcfa?w=800&q=80"
    ],
    description: "Caneca artesanal de cerâmica com esmalte vitrificado, acabamento manual e capacidade de 500 ml.",
    variants: defaultVariants(675, null)
  },
  {
    id: 2,
    name: "Auriculares sem fios Duo ANC Pro",
    price: 1190,
    oldPrice: 1490,
    flag: "Promoção",
    storeId: 1,
    category: "Tecnologia",
    img: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=400&q=80",
    images: [
      "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=800&q=80",
      "https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?w=800&q=80"
    ],
    description: "Bluetooth 5.3 com cancelamento de ruído ativo (ANC). Até 28h de autonomia total com o estojo. Resistência IPX4 a suor e chuva leve. Compatível com Android e iPhone.",
    variants: [
      { id: "preto", label: "Preto Grafite", price: 1190, oldPrice: 1490, stock: 8 },
      { id: "branco", label: "Branco Pérola", price: 1190, oldPrice: 1490, stock: 0 },
      { id: "azul", label: "Azul Meia-Noite", price: 1250, oldPrice: 1490, stock: 5 }
    ]
  },
  {
    id: 3,
    name: "Ténis Urban Runner Ultra Leve",
    price: 2400,
    oldPrice: null,
    flag: "",
    storeId: 3,
    category: "Moda",
    img: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80",
    images: [
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&q=80"
    ],
    description: "Ténis urbano respirável com sola de resposta rápida, cabedal leve e amortecimento para uso diário.",
    variants: [
      { id: "39", label: "Tamanho 39", price: 2400, oldPrice: null, stock: 4 },
      { id: "40", label: "Tamanho 40", price: 2400, oldPrice: null, stock: 6 },
      { id: "41", label: "Tamanho 41", price: 2400, oldPrice: null, stock: 0 },
      { id: "42", label: "Tamanho 42", price: 2450, oldPrice: null, stock: 3 }
    ]
  },
  {
    id: 4,
    name: "Mochila casual impermeável preta",
    price: 1150,
    oldPrice: 1450,
    flag: "Popular",
    storeId: 1,
    category: "Moda",
    img: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&q=80",
    images: [
      "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&q=80"
    ],
    description: "Mochila impermeável para portátil 15”, compartimentos organizados e alças reforçadas para o dia a dia.",
    variants: defaultVariants(1150, 1450)
  },
  {
    id: 5,
    name: "Cabaz de frescos da Mercearia",
    price: 850,
    oldPrice: null,
    flag: "Fresco",
    storeId: 2,
    category: "Alimentação",
    img: "https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&q=80",
    images: [
      "https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&q=80"
    ],
    description: "Seleção sazonal de hortícolas, frutas da estação e mercearia essencial montada no dia pela loja.",
    variants: defaultVariants(850, null, 14)
  },
  {
    id: 6,
    name: "Perfume amadeirado Nair Privé",
    price: 1350,
    oldPrice: null,
    flag: "Novo",
    storeId: 3,
    category: "Beleza",
    img: "https://images.unsplash.com/photo-1541643600914-78b084683601?w=400&q=80",
    images: [
      "https://images.unsplash.com/photo-1541643600914-78b084683601?w=800&q=80"
    ],
    description: "Fragrância amadeirada com notas de âmbar, baunilha e sândalo. Eau de parfum 50 ml.",
    variants: defaultVariants(1350, null, 7)
  }
];

export function getStoreById(id) {
  return STORES.find((store) => String(store.id) === String(id)) || null;
}

export function getProductById(id) {
  return PRODUCTS.find((product) => String(product.id) === String(id)) || null;
}

export function getStoreProducts(storeId) {
  return getStoreById(storeId)
    ? PRODUCTS.filter((product) => String(product.storeId) === String(storeId))
    : [];
}

export function getProductDetail(id) {
  const product = getProductById(id);
  if (!product) return null;
  const store = getStoreById(product.storeId);
  const images = product.images?.length ? product.images : [product.img];
  return {
    ...product,
    store,
    images,
    description: product.description || "Artigo selecionado pela loja parceira Kamby.",
    variants: product.variants?.length ? product.variants : defaultVariants(product.price, product.oldPrice)
  };
}
