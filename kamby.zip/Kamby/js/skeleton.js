/* ── GERADORES DE SKELETON (HTML puro, sem estado) ── */

export function skelProductCard() {
  return `
    <div class="k-skel-card" aria-hidden="true">
      <div class="k-skel k-skel-thumb"></div>
      <div class="k-skel k-skel--text k-skel-w-80"></div>
      <div class="k-skel k-skel--text k-skel-w-60"></div>
      <div class="k-skel k-skel--text k-skel-w-40" style="height:14px;"></div>
    </div>
  `;
}

export function skelProductGrid(count = 6) {
  return `<div class="k-grid" aria-hidden="true">${Array.from({ length: count }, skelProductCard).join('')}</div>`;
}

export function skelStoreRow() {
  return `
    <div class="k-skel-row" aria-hidden="true">
      <div class="k-skel k-skel-row-thumb"></div>
      <div class="k-skel-row-lines">
        <div class="k-skel k-skel--text k-skel-w-60"></div>
        <div class="k-skel k-skel--text k-skel-w-40"></div>
      </div>
      <div class="k-skel k-skel-chevron"></div>
    </div>
  `;
}

export function skelStoreList(count = 3) {
  return `<div class="k-skel-stack" aria-hidden="true">${Array.from({ length: count }, skelStoreRow).join('')}</div>`;
}

export function skelStorePage() {
  return `
    <div aria-hidden="true">
      <div class="k-skel k-skel-store-cover"></div>
      <div class="k-skel-store-body">
        <div class="k-skel k-skel--circle k-skel-avatar"></div>
        <div class="k-skel k-skel--text k-skel-w-60" style="height:16px;"></div>
        <div class="k-skel k-skel--text k-skel-w-40"></div>
        <div class="k-skel k-skel--text k-skel-w-80"></div>
      </div>
      ${skelProductGrid(4)}
    </div>
  `;
}

export function skelPDP() {
  return `
    <div aria-hidden="true">
      <div class="k-skel k-skel-pdp-media"></div>
      <div class="k-skel-pdp-body">
        <div class="k-skel k-skel--text k-skel-w-80" style="height:18px;"></div>
        <div class="k-skel k-skel--text k-skel-w-40" style="height:20px;"></div>
        <div class="k-skel-pdp-variants">
          <div class="k-skel k-skel-chip"></div>
          <div class="k-skel k-skel-chip"></div>
          <div class="k-skel k-skel-chip"></div>
        </div>
        <div class="k-skel k-skel--text k-skel-w-60"></div>
        <div class="k-skel k-skel--text k-skel-w-80"></div>
      </div>
    </div>
  `;
}

export function skelCartGroup() {
  return `
    <div class="k-skel-cart" aria-hidden="true">
      <div class="k-skel-cart-head">
        <div class="k-skel-row-lines">
          <div class="k-skel k-skel--text k-skel-w-60"></div>
          <div class="k-skel k-skel--text k-skel-w-40"></div>
        </div>
        <div class="k-skel k-skel-chevron"></div>
      </div>
      <div class="k-skel-cart-body">
        <div class="k-skel k-skel-cart-thumb"></div>
        <div class="k-skel-row-lines" style="align-items:flex-end;">
          <div class="k-skel k-skel--text k-skel-w-40"></div>
          <div class="k-skel k-skel--text k-skel-w-60"></div>
        </div>
      </div>
    </div>
  `;
}

export function skelCartGroups(count = 2) {
  return `<div class="k-skel-stack" aria-hidden="true">${Array.from({ length: count }, skelCartGroup).join('')}</div>`;
}

export function skelCartItem() {
  return `
    <div class="k-skel-cart-item" aria-hidden="true">
      <div class="k-skel k-skel-cart-item-thumb"></div>
      <div class="k-skel-row-lines">
        <div class="k-skel k-skel--text k-skel-w-80"></div>
        <div class="k-skel k-skel--text k-skel-w-40"></div>
        <div class="k-skel k-skel--text k-skel-w-60"></div>
      </div>
      <div class="k-skel k-skel-cart-item-side"></div>
    </div>
  `;
}

export function skelCartItems(count = 3) {
  return `<div aria-hidden="true">${Array.from({ length: count }, skelCartItem).join('')}</div>`;
}

export function skelSearchRow() {
  return `
    <div class="k-skel-row" aria-hidden="true" style="background:transparent;border-color:transparent;padding:10px;">
      <div class="k-skel" style="width:46px;height:46px;border-radius:var(--k-radius-sm);flex-shrink:0;"></div>
      <div class="k-skel-row-lines">
        <div class="k-skel k-skel--text k-skel-w-60"></div>
        <div class="k-skel k-skel--text k-skel-w-40"></div>
      </div>
    </div>
  `;
}

export function skelSearchRows(count = 4) {
  return `<div aria-hidden="true">${Array.from({ length: count }, skelSearchRow).join('')}</div>`;
}

/* ── MOTOR DE IMAGENS (listeners globais + MutationObserver) ── */

const boundImages = new WeakSet();
let loaderStarted = false;

function shellOf(img) {
  return img.closest('.k-img-shell');
}

function hasSource(img) {
  const src = img.getAttribute('src');
  return typeof src === 'string' && src.trim().length > 0;
}

function markLoaded(img) {
  const shell = shellOf(img);
  if (!shell) return;
  shell.setAttribute('data-loaded', 'true');
  shell.removeAttribute('data-error');
}

function markError(img) {
  const shell = shellOf(img);
  if (!shell) return;
  shell.setAttribute('data-loaded', 'true');
  shell.setAttribute('data-error', 'true');
  if (shell.dataset.fallback !== 'icon' && !shell.dataset.initial) {
    const label = (img.getAttribute('alt') || '').trim();
    shell.dataset.initial = label.charAt(0).toUpperCase() || '?';
  }
  if (shell.dataset.fallback !== 'icon') shell.dataset.fallback = 'initial';
}

function syncImageState(img) {
  const shell = shellOf(img);
  if (!shell) return;

  shell.removeAttribute('data-error');

  if (!hasSource(img)) {
    shell.setAttribute('data-loaded', 'true');
    return;
  }

  if (img.complete) {
    if (img.naturalWidth > 0) markLoaded(img);
    else markError(img);
    return;
  }

  shell.setAttribute('data-loaded', 'false');
}

function bindImage(img) {
  if (!(img instanceof HTMLImageElement) || boundImages.has(img)) return;
  if (!img.matches('img[data-skel]')) return;
  if (!shellOf(img)) return;

  boundImages.add(img);
  if (!img.hasAttribute('decoding')) img.decoding = 'async';
  syncImageState(img);
}

export function scanImages(root = document) {
  root.querySelectorAll('img[data-skel]').forEach(bindImage);
}

export function initImageLoader() {
  if (loaderStarted) return;
  loaderStarted = true;

  document.documentElement.classList.add('js');

  document.addEventListener('load', (event) => {
    const target = event.target;
    if (target instanceof HTMLImageElement && target.matches('img[data-skel]')) markLoaded(target);
  }, true);

  document.addEventListener('error', (event) => {
    const target = event.target;
    if (target instanceof HTMLImageElement && target.matches('img[data-skel]')) markError(target);
  }, true);

  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.type === 'attributes') {
        const target = mutation.target;
        if (target instanceof HTMLImageElement) syncImageState(target);
        return;
      }
      mutation.addedNodes.forEach((node) => {
        if (node.nodeType !== 1) return;
        if (node instanceof HTMLImageElement) bindImage(node);
        if (typeof node.querySelectorAll === 'function') {
          node.querySelectorAll('img[data-skel]').forEach(bindImage);
        }
      });
    });
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['src']
  });

  scanImages();
}

/* ── BASE PARA ECRÃS ASSÍNCRONOS (futuro backend/API) ── */
export function withSkeleton(container, skeletonHTML, loader, { delay = 150 } = {}) {
  const timer = setTimeout(() => {
    container.setAttribute('aria-busy', 'true');
    container.innerHTML = skeletonHTML;
  }, delay);

  return Promise.resolve()
    .then(loader)
    .then((html) => {
      clearTimeout(timer);
      container.innerHTML = html;
      container.removeAttribute('aria-busy');
      scanImages(container);
      return html;
    })
    .catch((error) => {
      clearTimeout(timer);
      container.removeAttribute('aria-busy');
      throw error;
    });
}
