import { getProductById } from './data.js';

const FAVORITES_KEY = 'kamby_favorites';

function readFavorites() {
  try {
    const parsed = JSON.parse(localStorage.getItem(FAVORITES_KEY) || '[]');
    return Array.isArray(parsed) ? parsed.map(Number).filter((id) => Number.isFinite(id)) : [];
  } catch {
    return [];
  }
}

function writeFavorites(favorites) {
  localStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites));
  window.dispatchEvent(new CustomEvent('favorites-updated', { detail: { ids: favorites } }));
}

export function getFavorites() {
  return readFavorites();
}

export function isFavorite(productId) {
  return readFavorites().includes(Number(productId));
}

export function getFavoriteProducts() {
  const seen = new Set();
  return readFavorites()
    .slice()
    .reverse()
    .filter((id) => {
      if (seen.has(id)) return false;
      seen.add(id);
      return true;
    })
    .map((id) => getProductById(id))
    .filter(Boolean);
}

export function getFavoriteCount() {
  return getFavoriteProducts().length;
}

export function toggleFavorite(productId) {
  const id = Number(productId);
  const favorites = readFavorites();
  const next = favorites.includes(id) ? favorites.filter((item) => item !== id) : [...favorites, id];
  writeFavorites(next);
  return next.includes(id);
}

export function removeFavorite(productId) {
  const id = Number(productId);
  const favorites = readFavorites();
  if (!favorites.includes(id)) return false;
  writeFavorites(favorites.filter((item) => item !== id));
  return true;
}
