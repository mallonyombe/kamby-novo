import { getProductDetail, PRODUCTS, STORES } from './data.js';
import { addToCart } from './cart.js';

export function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (char) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    "'": '&#39;',
    '"': '&quot;'
  }[char]));
}

export const LOGO_SVG = `
  <svg class="k-logo" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <defs>
      <linearGradient id="k-top-grad" x1="10%" y1="90%" x2="90%" y2="10%">
        <stop offset="0%" stop-color="#FFD100"/>
        <stop offset="50%" stop-color="#FF9D00"/>
        <stop offset="100%" stop-color="#FF6B00"/>
      </linearGradient>
      <linearGradient id="k-bot-grad" x1="10%" y1="30%" x2="90%" y2="90%">
        <stop offset="0%" stop-color="#FF8A00"/>
        <stop offset="40%" stop-color="#F5006B"/>
        <stop offset="100%" stop-color="#A30049"/>
      </linearGradient>
    </defs>
    <path d="M 14 86 C 14 45, 35 5, 65 5 C 85 5, 95 15, 95 30 C 95 50, 75 70, 45 82 C 30 87, 20 88, 14 86 Z" fill="url(#k-top-grad)"/>
    <path d="M 14 86 C 25 95, 45 100, 65 98 C 85 96, 95 80, 95 65 C 95 50, 80 43, 55 44 C 35 45, 20 60, 14 86 Z" fill="url(#k-bot-grad)"/>
  </svg>
`;

/* ── SISTEMA DE ÍCONES PADRONIZADO (Grelha 24x24 · Traço 2.0) ── */
export const ICONS = {
  // Ícone de Voltar: Exatamente o mesmo chevron invertido das listas, com traço 2.0
  back: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>`,
  
  // Seta de navegação para a frente (mesmo ângulo e espessura do back)
  chevronRight: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18l6-6-6-6"/></svg>`,
  
  search: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>`,
  
  cart: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>`,
  
  heart: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>`,
  
  close: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>`,
  
  filter: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="6" x2="20" y2="6"></line><line x1="7" y1="12" x2="17" y2="12"></line><line x1="10" y1="18" x2="14" y2="18"></line></svg>`,
  
  check: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>`,
  
  settings: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>`,
  
  trash: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>`,
  
  verified: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#FF8A00" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>`,

  eye: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>`,

  eyeOff: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"></path><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>`,

  user: `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>`,

  lock: `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"></rect><path d="M8 10V7a4 4 0 0 1 8 0v3"></path></svg>`,
  mail: `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"></rect><path d="m22 7-10 6L2 7"></path></svg>`,
  shieldCheck: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><path d="m9 12 2 2 4-4"></path></svg>`,

  truck: `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="14" height="12" rx="1"></rect><path d="M15 8h4l3 4v4h-7"></path><circle cx="6" cy="19" r="2"></circle><circle cx="18" cy="19" r="2"></circle></svg>`,


  whatsapp: `<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91C2.13 13.66 2.59 15.36 3.45 16.86L2.05 22L7.3 20.62C8.75 21.41 10.38 21.83 12.04 21.83C17.5 21.83 21.95 17.38 21.95 11.92C21.95 9.27 20.92 6.78 19.05 4.91C17.18 3.03 14.69 2 12.04 2M12.05 3.67C14.25 3.67 16.31 4.53 17.87 6.09C19.42 7.65 20.28 9.72 20.28 11.92C20.28 16.46 16.58 20.15 12.04 20.15C10.56 20.15 9.11 19.76 7.85 19L7.55 18.83L4.43 19.65L5.26 16.61L5.06 16.29C4.24 14.99 3.81 13.47 3.81 11.91C3.81 7.37 7.5 3.67 12.05 3.67Z"/></svg>`
};

/* ── HAPTIC FEEDBACK SILENCIOSO ── */
export function triggerHaptic(type = 'light') {
  if (!navigator.vibrate) return;
  if (type === 'light') navigator.vibrate(8);
  else if (type === 'medium') navigator.vibrate(18);
  else if (type === 'success') navigator.vibrate([10, 40, 15]);
  else if (type === 'error') navigator.vibrate([40, 60, 40]);
}

/* ── SISTEMA DE TOAST ── */
export function initToast() {
  const modalRoot = document.getElementById('modal-root') || document.body;
  const toast = document.createElement('div');
  toast.className = 'k-toast';
  toast.id = 'toast';
  toast.innerHTML = `${ICONS.check} <span>Guardado no carrinho</span>`;
  modalRoot.appendChild(toast);

  window.showToast = (msg) => {
    if (msg) toast.querySelector('span').textContent = msg;
    toast.setAttribute('data-show', 'true');
    triggerHaptic('success');
    setTimeout(() => toast.setAttribute('data-show', 'false'), 2400);
  };
}

/* ── LIGHTBOX (Com navegação por toque e botão voltar do telefone) ── */
let currentLightboxImages = [];
let currentLightboxIndex = 0;

export function initLightbox() {
  const modalRoot = document.getElementById('modal-root') || document.body;
  const lb = document.createElement('div');
  lb.className = 'k-lightbox';
  lb.id = 'lightbox';
  lb.innerHTML = `
    <div class="k-lightbox-header">
      <span class="k-lightbox-counter" id="lb-counter">1 / 1</span>
      <div class="k-lightbox-close" id="lb-close">${ICONS.close}</div>
    </div>
    <div class="k-lightbox-viewport" id="lb-viewport">
      <div class="k-img-shell k-lightbox-shell" data-fallback="icon">
        <img src="" class="k-lightbox-img" id="lb-img" alt="Zoom" data-skel>
      </div>
    </div>
    <div class="k-lightbox-dots" id="lb-dots"></div>
  `;
  modalRoot.appendChild(lb);

  const imgEl = document.getElementById('lb-img');
  const counterEl = document.getElementById('lb-counter');
  const dotsEl = document.getElementById('lb-dots');

  const updateDisplay = () => {
    imgEl.src = currentLightboxImages[currentLightboxIndex];
    counterEl.textContent = `${currentLightboxIndex + 1} / ${currentLightboxImages.length}`;
    dotsEl.innerHTML = currentLightboxImages.map((_, i) => `
      <div class="pdp-dot" data-active="${i === currentLightboxIndex}"></div>
    `).join('');
  };

  const closeLb = () => {
    lb.setAttribute('data-open', 'false');
  };

  document.getElementById('lb-close').addEventListener('click', () => {
    if (window.history.state?.lightboxOpen) {
      window.history.back();
    } else {
      closeLb();
    }
  });

  window.addEventListener('popstate', () => {
    if (lb.getAttribute('data-open') === 'true') {
      closeLb();
    }
  });

  let startX = 0;
  let startY = 0;
  let deltaX = 0;
  let deltaY = 0;

  const viewport = document.getElementById('lb-viewport');
  viewport.addEventListener('touchstart', (e) => {
    startX = e.touches[0].clientX;
    startY = e.touches[0].clientY;
    deltaX = 0;
    deltaY = 0;
  }, { passive: true });

  viewport.addEventListener('touchmove', (e) => {
    deltaX = e.touches[0].clientX - startX;
    deltaY = e.touches[0].clientY - startY;

    if (Math.abs(deltaY) > Math.abs(deltaX) && deltaY > 0) {
      imgEl.style.transform = `translateY(${deltaY * 0.7}px) scale(${1 - deltaY / 1000})`;
    } else {
      imgEl.style.transform = `translateX(${deltaX * 0.6}px)`;
    }
  }, { passive: true });

  viewport.addEventListener('touchend', () => {
    imgEl.style.transform = '';
    
    // Swipe vertical para fechar
    if (deltaY > 120) {
      if (window.history.state?.lightboxOpen) window.history.back();
      else closeLb();
      return;
    }

    // Swipe horizontal para alternar fotos
    if (deltaX < -50 && currentLightboxIndex < currentLightboxImages.length - 1) {
      currentLightboxIndex++;
      updateDisplay();
      triggerHaptic('light');
    } else if (deltaX > 50 && currentLightboxIndex > 0) {
      currentLightboxIndex--;
      updateDisplay();
      triggerHaptic('light');
    }
  });

  window.openLightbox = (images, initialIndex = 0) => {
    currentLightboxImages = Array.isArray(images) ? images : [images];
    currentLightboxIndex = initialIndex;
    updateDisplay();
    lb.setAttribute('data-open', 'true');
    window.history.pushState({ lightboxOpen: true }, '');
    triggerHaptic('light');
  };

  window.closeLightbox = closeLb;
}

/* ── DOCUMENTOS LEGAIS (TEXTO PROVISÓRIO DE DEMONSTRAÇÃO) ── */
const LEGAL_CONTENT = {
  terms: {
    title: 'Termos de Serviço',
    body: `
      <p class="k-legal-updated">Versão de demonstração · novembro de 2026</p>
      <h3>1. Aceitação</h3>
      <p>Ao criares uma conta Kamby, concordas com estes termos e com a Política de Privacidade. Se não concordares, podes continuar a navegar como visitante.</p>
      <h3>2. Conta</h3>
      <p>Deves fornecer informações verdadeiras e manter a confidencialidade da tua palavra-passe. A conta é pessoal e destina-se a maiores de 18 anos.</p>
      <h3>3. Compras e pagamentos</h3>
      <p>Os pedidos são confirmados diretamente com a loja através do WhatsApp. Os preços, prazos e formas de pagamento (M-Pesa, e-Mola ou numerário) são apresentados antes da confirmação.</p>
      <h3>4. Entregas e devoluções</h3>
      <p>A Kamby Express entrega no mesmo dia nas zonas de cobertura. Pedidos de devolução ou troca devem ser feitos diretamente à loja parceira.</p>
      <h3>5. Contacto</h3>
      <p>Para questões sobre estes termos, contacta o apoio Kamby pelo WhatsApp.</p>
    `
  },
  privacy: {
    title: 'Política de Privacidade',
    body: `
      <p class="k-legal-updated">Versão de demonstração · novembro de 2026</p>
      <h3>1. Dados que guardamos</h3>
      <p>Esta demonstração guarda o nome, email, sexo (opcional) e uma versão protegida da palavra-passe apenas no armazenamento local do teu navegador.</p>
      <h3>2. Onde ficam os dados</h3>
      <p>Nenhuma conta desta demonstração é enviada para servidores externos. O carrinho e os favoritos também permanecem no dispositivo.</p>
      <h3>3. Partilha</h3>
      <p>Ao concluíres um pedido, os dados necessários são incluídos na mensagem de WhatsApp que envias à loja.</p>
      <h3>4. Os teus direitos</h3>
      <p>Podes eliminar a conta na secção Perfil. Esta ação remove a conta e a sessão deste dispositivo. Carrinho e favoritos locais não são alterados.</p>
      <h3>5. Contacto</h3>
      <p>Para questões de privacidade, contacta o apoio Kamby pelo WhatsApp.</p>
    `
  }
};

export function openLegalSheet(kind = 'terms') {
  const content = LEGAL_CONTENT[kind] || LEGAL_CONTENT.terms;
  const sheet = document.getElementById('sheet');
  const backdrop = document.getElementById('sheet-backdrop');
  if (!sheet || !backdrop) return;

  sheet.innerHTML = `
    <div class="k-sheet-handle"></div>
    <div class="k-sheet-header">
      <h2>${content.title}</h2>
      <button class="k-sheet-close" onclick="window.closeSheet()" aria-label="Fechar">${ICONS.close}</button>
    </div>
    <div class="k-legal-body">${content.body}</div>
    <button class="k-btn-primary" onclick="window.closeSheet()">Concluído</button>
  `;
  sheet.setAttribute('aria-label', content.title);

  setTimeout(() => {
    sheet.setAttribute('data-open', 'true');
    backdrop.setAttribute('data-open', 'true');
    triggerHaptic('light');
  }, 10);
}

/* ── BOTTOM SHEETS NATIVOS ── */
let sheetProduct = null;
let filterContext = 'store';
let filterSelection = 'recent';

export function initSheets() {
  const modalRoot = document.getElementById('modal-root') || document.body;
  const backdrop = document.createElement('div');
  backdrop.className = 'k-sheet-backdrop';
  backdrop.id = 'sheet-backdrop';
  modalRoot.appendChild(backdrop);

  const sheet = document.createElement('div');
  sheet.className = 'k-sheet';
  sheet.id = 'sheet';
  sheet.setAttribute('role', 'dialog');
  sheet.setAttribute('aria-modal', 'true');
  sheet.setAttribute('aria-hidden', 'true');
  sheet.setAttribute('inert', '');
  modalRoot.appendChild(sheet);

  backdrop.addEventListener('click', () => window.closeSheet());

  let sheetReturnFocus = null;
  let sheetWasOpen = false;

  const syncSheetState = () => {
    const isOpen = sheet.getAttribute('data-open') === 'true';
    sheet.setAttribute('aria-hidden', String(!isOpen));
    if (isOpen) sheet.removeAttribute('inert');
    else sheet.setAttribute('inert', '');

    if (isOpen && !sheetWasOpen) {
      const active = document.activeElement;
      sheetReturnFocus = active && active !== document.body ? active : null;
      const preferred = sheet.querySelector('[data-autofocus]');
      const focusTarget = preferred || sheet.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
      if (focusTarget) {
        setTimeout(() => {
          if (sheet.getAttribute('data-open') === 'true') focusTarget.focus({ preventScroll: true });
        }, 30);
      }
    } else if (!isOpen && sheetWasOpen && sheetReturnFocus) {
      const target = sheetReturnFocus;
      sheetReturnFocus = null;
      setTimeout(() => target.focus({ preventScroll: true }), 10);
    }

    sheetWasOpen = isOpen;
  };

  new MutationObserver(syncSheetState).observe(sheet, {
    attributes: true,
    attributeFilter: ['data-open']
  });
  syncSheetState();

  sheet.addEventListener('keydown', (event) => {
    if (event.key !== 'Tab') return;
    const focusable = [...sheet.querySelectorAll('button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])')]
      .filter((element) => element.offsetParent !== null);
    if (focusable.length === 0) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  });

  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    if (sheet.getAttribute('data-open') !== 'true') return;
    event.preventDefault();
    window.closeSheet();
  });

  window.closeSheet = () => {
    sheet.style.transform = '';
    sheet.setAttribute('data-open', 'false');
    backdrop.setAttribute('data-open', 'false');
  };

  // Arrastar para baixo fecha a folha
  let startY = 0;
  let currentY = 0;
  sheet.addEventListener('touchstart', (e) => { startY = e.touches[0].clientY; }, { passive: true });
  sheet.addEventListener('touchmove', (e) => {
    currentY = e.touches[0].clientY;
    const deltaY = currentY - startY;
    if (deltaY > 0) sheet.style.transform = `translate(-50%, ${deltaY}px)`;
  }, { passive: true });
  sheet.addEventListener('touchend', () => {
    const deltaY = currentY - startY;
    if (deltaY > 110) window.closeSheet();
    else sheet.style.transform = 'translate(-50%, 0)';
    startY = 0; currentY = 0;
  });

  window.openCartSheet = (productId) => {
    const data = getProductDetail(productId);
    if (!data) {
      window.showToast('Artigo indisponível');
      return;
    }

    sheetProduct = data;
    const optionsHTML = data.variants.map(v => `
      <div class="k-sheet-opt-card" role="radio" tabindex="${v.stock === 0 ? -1 : 0}" aria-checked="false" aria-selected="false" data-price="${v.price}" data-id="${escapeHtml(v.id)}" ${v.stock === 0 ? 'data-sold-out="true" aria-disabled="true" style="opacity:0.35;pointer-events:none;"' : ''} onclick="window.selectSheetVariant(this)">
        <div>
          <div style="font-size:13.5px;font-weight:700;">${escapeHtml(v.label)}</div>
          <div style="font-size:12px;color:var(--k-ink-2);">${v.price.toLocaleString('pt-MZ')} MT</div>
        </div>
        <div class="k-sheet-radio"></div>
      </div>
    `).join('');

    sheet.innerHTML = `
      <div class="k-sheet-handle"></div>
      <div class="k-sheet-header">
        <h2>Adicionar ao carrinho</h2>
        <button class="k-sheet-close" onclick="window.closeSheet()" aria-label="Fechar">${ICONS.close}</button>
      </div>
      <div style="display:flex;gap:12px;margin-bottom:20px;align-items:center;">
        <span class="k-img-shell k-sheet-thumb-shell" data-fallback="icon">
          <img src="${escapeHtml(data.images[0])}" alt="${escapeHtml(data.name)}" data-skel>
        </span>
        <div>
          <div style="font-size:14px;font-weight:700;">${escapeHtml(data.name)}</div>
          <div style="font-size:12px;color:var(--k-ink-2);">${escapeHtml(data.store?.name || 'Loja Kamby')}</div>
        </div>
      </div>
      <div class="k-sheet-options" role="radiogroup" aria-label="Opções do artigo">${optionsHTML}</div>
      <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 0;border-top:1px solid var(--k-border-subtle);border-bottom:1px solid var(--k-border-subtle);margin-bottom:18px;">
        <span style="font-size:14px;font-weight:600;color:var(--k-ink-2);">Quantidade</span>
        <div class="k-stepper">
          <button id="sheet-qty-minus" onclick="window.updateSheetQty(-1)" aria-label="Diminuir quantidade" disabled>−</button>
          <span id="sheet-qty">1</span>
          <button onclick="window.updateSheetQty(1)" aria-label="Aumentar quantidade">+</button>
        </div>
      </div>
      <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:18px;">
        <span style="font-size:14px;color:var(--k-ink-2);">Subtotal</span>
        <span style="font-size:20px;font-weight:800;" id="sheet-total">0 MT</span>
      </div>
      <button class="k-btn-primary" onclick="window.confirmAddToCart()">Guardar no carrinho</button>
    `;

    const firstAvailable = sheet.querySelector('.k-sheet-opt-card:not([data-sold-out="true"])') || sheet.querySelector('.k-sheet-opt-card');
    if (firstAvailable) {
      firstAvailable.setAttribute('aria-selected', 'true');
      firstAvailable.setAttribute('aria-checked', 'true');
    }
    window.sheetQty = 1;
    window.updateSheetTotal();

    setTimeout(() => {
      sheet.setAttribute('data-open', 'true');
      backdrop.setAttribute('data-open', 'true');
      triggerHaptic('light');
    }, 10);
  };

  const sorts = [
    { id: 'recent', label: 'Mais recentes' },
    { id: 'price-asc', label: 'Menor preço' },
    { id: 'price-desc', label: 'Maior preço' }
  ];

  window.openFilterSheet = (context = 'store', selectedSort = 'recent') => {
    filterContext = context;
    filterSelection = sorts.some((sort) => sort.id === selectedSort) ? selectedSort : 'recent';
    sheet.innerHTML = `
      <div class="k-sheet-handle"></div>
      <div class="k-sheet-header">
        <h2>Filtrar e ordenar</h2>
        <button class="k-sheet-close" onclick="window.closeSheet()" aria-label="Fechar">${ICONS.close}</button>
      </div>
      <div class="k-filter-list" role="radiogroup" aria-label="Ordenação">
        ${sorts.map((sort) => `
          <div class="k-filter-option" role="radio" tabindex="0" aria-checked="${sort.id === filterSelection}" data-sort="${sort.id}" data-active="${sort.id === filterSelection}" onclick="window.selectFilter(this)">
            <span>${sort.label}</span>
            ${ICONS.check}
          </div>
        `).join('')}
      </div>
      <button class="k-btn-primary" onclick="window.applyFilterSelection()">Aplicar filtros</button>
    `;
    setTimeout(() => {
      sheet.setAttribute('data-open', 'true');
      backdrop.setAttribute('data-open', 'true');
      triggerHaptic('light');
    }, 10);
  };

  window.selectFilter = (el) => {
    if (!el?.dataset?.sort) return;
    filterSelection = el.dataset.sort;
    sheet.querySelectorAll('.k-filter-option').forEach(o => {
      const active = o.dataset.sort === filterSelection;
      o.setAttribute('data-active', String(active));
      o.setAttribute('aria-checked', String(active));
    });
    triggerHaptic('light');
  };

  window.applyFilterSelection = () => {
    window.closeSheet();
    window.dispatchEvent(new CustomEvent('kamby-sort-apply', {
      detail: { context: filterContext, sort: filterSelection }
    }));
    triggerHaptic('success');
  };

  window.selectSheetVariant = (el) => {
    if (!el || el.dataset.soldOut === 'true') return;
    sheet.querySelectorAll('.k-sheet-opt-card').forEach(c => {
      c.setAttribute('aria-selected', 'false');
      c.setAttribute('aria-checked', 'false');
    });
    el.setAttribute('aria-selected', 'true');
    el.setAttribute('aria-checked', 'true');
    window.updateSheetTotal();
    triggerHaptic('light');
  };

  window.updateSheetQty = (delta) => {
    const nextQty = Math.max(1, window.sheetQty + delta);
    if (nextQty === window.sheetQty) return;
    window.sheetQty = nextQty;
    document.getElementById('sheet-qty').textContent = window.sheetQty;
    const minusBtn = document.getElementById('sheet-qty-minus');
    if (minusBtn) minusBtn.disabled = window.sheetQty <= 1;
    window.updateSheetTotal();
    triggerHaptic('light');
  };

  window.updateSheetTotal = () => {
    const selected = sheet.querySelector('.k-sheet-opt-card[aria-selected="true"]');
    if (!selected) return;
    document.getElementById('sheet-total').textContent = `${(parseInt(selected.dataset.price) * window.sheetQty).toLocaleString('pt-MZ')} MT`;
  };

  window.confirmAddToCart = () => {
    const selected = sheet.querySelector('.k-sheet-opt-card[aria-selected="true"]');
    if (!selected) return;
    const variantId = selected.dataset.id;
    const variant = sheetProduct?.variants.find(v => v.id === variantId);
    if (!sheetProduct || !variant) return;
    addToCart(sheetProduct, variant, window.sheetQty);
    window.closeSheet();
    window.showToast("Artigo adicionado ao carrinho");
  };
}

/* ── PESQUISA ── */
export function initSearch() {
  const modalRoot = document.getElementById('modal-root') || document.body;
  const overlay = document.createElement('div');
  overlay.className = 'k-search-overlay';
  overlay.innerHTML = `
    <div class="k-search-header">
      <div class="k-search-input-wrap">
        ${ICONS.search}
        <input type="search" class="k-search-input" placeholder="Pesquisar artigos ou lojas..." autocomplete="off" aria-label="Pesquisar artigos ou lojas">
      </div>
      <button class="k-search-cancel">Cancelar</button>
    </div>
    <div class="k-search-results" id="search-results" role="listbox" aria-label="Resultados da pesquisa"></div>
  `;
  modalRoot.appendChild(overlay);

  const input = overlay.querySelector('.k-search-input');
  const resultsEl = overlay.querySelector('#search-results');

  const renderHint = () => {
    resultsEl.innerHTML = `<div class="k-search-empty">Pesquisa produtos, categorias e lojas parceiras em Moçambique.</div>`;
  };

  const goTo = (hash) => {
    overlay.setAttribute('data-open', 'false');
    input.blur();
    window.location.hash = hash;
  };

  const renderResults = (query) => {
    const q = query.trim().toLocaleLowerCase('pt-MZ');
    if (!q) {
      renderHint();
      return;
    }

    const productMatches = PRODUCTS.filter((product) => {
      const store = STORES.find((item) => item.id === product.storeId);
      const haystack = [product.name, product.category, store?.name, store?.area].filter(Boolean).join(' ').toLocaleLowerCase('pt-MZ');
      return haystack.includes(q);
    }).slice(0, 6);

    const storeMatches = STORES.filter((store) => {
      const haystack = [store.name, store.area, store.desc].filter(Boolean).join(' ').toLocaleLowerCase('pt-MZ');
      return haystack.includes(q);
    }).slice(0, 4);

    if (productMatches.length === 0 && storeMatches.length === 0) {
      resultsEl.innerHTML = `<div class="k-search-empty">Nada encontrado para “${escapeHtml(query.trim())}”. Tenta outra palavra.</div>`;
      return;
    }

    const productsHTML = productMatches.map((product) => `
      <button class="k-search-result" role="option" onclick="window.__kambySearchGo('#/p/${product.id}')">
        <span class="k-img-shell k-search-thumb-shell" data-fallback="icon">
          <img src="${escapeHtml(product.img)}" alt="${escapeHtml(product.name)}" loading="lazy" data-skel>
        </span>
        <span class="k-search-result-info">
          <span class="k-search-result-title">${escapeHtml(product.name)}</span>
          <span class="k-search-result-meta">${escapeHtml(product.category)} · ${product.price.toLocaleString('pt-MZ')} MT</span>
        </span>
        ${ICONS.chevronRight}
      </button>
    `).join('');

    const storesHTML = storeMatches.map((store) => `
      <button class="k-search-result" role="option" onclick="window.__kambySearchGo('#/loja/${store.id}')">
        <span class="k-img-shell k-search-thumb-shell">
          <img src="${escapeHtml(store.avatar)}" alt="${escapeHtml(store.name)}" loading="lazy" data-skel>
        </span>
        <span class="k-search-result-info">
          <span class="k-search-result-title">${escapeHtml(store.name)}</span>
          <span class="k-search-result-meta">${escapeHtml(store.area)}</span>
        </span>
        ${ICONS.chevronRight}
      </button>
    `).join('');

    resultsEl.innerHTML = `
      ${productsHTML ? `<div class="k-search-section-label">Artigos</div>${productsHTML}` : ''}
      ${storesHTML ? `<div class="k-search-section-label">Lojas</div>${storesHTML}` : ''}
    `;
  };

  overlay.querySelector('.k-search-cancel').addEventListener('click', () => closeOverlay());
  input.addEventListener('input', (event) => renderResults(event.target.value));
  input.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      const firstResult = resultsEl.querySelector('.k-search-result');
      if (firstResult) firstResult.click();
    }
  });
  window.addEventListener('hashchange', () => overlay.setAttribute('data-open', 'false'));

  const closeOverlay = () => {
    overlay.setAttribute('data-open', 'false');
    input.blur();
  };

  window.closeSearch = closeOverlay;
  window.__kambySearchGo = goTo;
  window.openSearch = () => {
    overlay.setAttribute('data-open', 'true');
    renderHint();
    setTimeout(() => input.focus(), 120);
    triggerHaptic('light');
  };
}