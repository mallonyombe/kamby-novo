import { ICONS, LOGO_SVG, initToast, initSheets, initSearch, initLightbox, triggerHaptic } from './ui.js';
import { initImageLoader } from './skeleton.js';
import { renderHome, initHome } from './screens/home.js';
import { renderPDP, initPDP } from './screens/product.js';
import { renderStore } from './screens/store.js';
import { renderStores } from './screens/stores.js';
import { renderCartOverview, renderStoreCart, initCart } from './screens/cart.js';
import { renderProfile, initProfile } from './screens/profile.js';
import { renderFavorites, initFavorites } from './screens/favorites.js';
import { renderAccountData, initAccountData } from './screens/account.js';
import { renderSecurity, initSecurity } from './screens/security.js';
import { renderAuthScreen, initAuthScreen } from './screens/auth.js';
import { getCartCount } from './cart.js';
import { canChangePassword, getUser } from './auth.js';

const headerEl = document.getElementById('app-header');
const viewEl = document.getElementById('app-view');
const navEl = document.getElementById('app-nav');
const tabs = document.querySelectorAll('.k-tab');

const AUTH_ROUTES = [
  '/bem-vindo',
  '/criar-conta',
  '/criar-conta/seguranca',
  '/criar-conta/verificar',
  '/entrar',
  '/recuperar',
  '/recuperar/codigo',
  '/recuperar/nova-palavra-passe'
];

const ONBOARDED_KEY = 'kamby_onboarded_v1';

const ACCOUNT_ROUTES = ['/perfil/dados', '/perfil/seguranca'];

const PROFILE_SUBPAGES = {
  '/favoritos': { title: 'Favoritos', back: '/perfil' },
  '/perfil/dados': { title: 'Dados pessoais', back: '/perfil' },
  '/perfil/seguranca': { title: 'Segurança', back: '/perfil' }
};

function isAuthRoute(route) {
  return AUTH_ROUTES.includes(route);
}

function hasOnboarded() {
  try {
    return localStorage.getItem(ONBOARDED_KEY) === '1';
  } catch {
    return true;
  }
}

function markOnboarded() {
  try {
    localStorage.setItem(ONBOARDED_KEY, '1');
  } catch {
    /* modo privado: segue sem persistir */
  }
}

export function updateNavBadge() {
  const count = getCartCount();
  const cartIconWrap = document.querySelector('.k-tab[data-route="/carrinho"] .k-tab-icon-wrap');
  if (!cartIconWrap) return;

  let badge = cartIconWrap.querySelector('.k-badge');
  if (count > 0) {
    if (!badge) {
      badge = document.createElement('span');
      badge.className = 'k-badge';
      cartIconWrap.appendChild(badge);
    }
    badge.textContent = count > 99 ? '99+' : count;
  } else if (badge) {
    badge.remove();
  }
}

export function reRoute() {
  router();
}

function updateHeader(route) {
  if (isAuthRoute(route)) {
    headerEl.style.display = 'none';
    viewEl.removeAttribute('data-pdp');
    viewEl.setAttribute('data-auth', 'true');
    return;
  }

  viewEl.removeAttribute('data-auth');

  if (route.startsWith('/p/') || route.startsWith('/loja/')) {
    headerEl.style.display = 'none';
    viewEl.setAttribute('data-pdp', 'true');
    return;
  }

  viewEl.removeAttribute('data-pdp');
  headerEl.style.display = 'flex';

  const subpage = PROFILE_SUBPAGES[route];
  if (subpage) {
    headerEl.innerHTML = `
      <button class="k-header-back" onclick="window.location.hash = '#${subpage.back}'" aria-label="Voltar">
        ${ICONS.back}
      </button>
      <span class="k-header-title">${subpage.title}</span>
      <div style="width: 40px;"></div>
    `;
    return;
  }

  // Cabeçalho do Carrinho da Loja: Botão de voltar limpo e sem bolha escura
  if (route.startsWith('/carrinho/')) {
    headerEl.innerHTML = `
      <button class="k-header-back" onclick="window.location.hash = '#/carrinho'" aria-label="Voltar aos carrinhos">
        ${ICONS.back}
      </button>
      <span class="k-header-title">Carrinho da Loja</span>
      <button class="k-header-action-text" onclick="window.location.hash = '#/carrinho'">
        Todos
      </button>
    `;
    return;
  }

  if (route === '/') {
    headerEl.innerHTML = `
      <div class="k-brand">
        ${LOGO_SVG}
        <span>Kamby</span>
      </div>
      <button class="k-header-btn" id="btn-search" aria-label="Pesquisar">${ICONS.search}</button>
    `;
    document.getElementById('btn-search')?.addEventListener('click', () => window.openSearch());
    return;
  }

  let title = route === '/lojas' ? 'Lojas' : route === '/carrinho' ? 'Carrinho' : 'Perfil';

  headerEl.innerHTML = `
    <span class="k-header-title">${title}</span>
    <div style="width: 40px;"></div>
  `;
}

function router() {
  const hash = window.location.hash.replace('#', '') || '/';
  const currentUser = getUser();

  if (hash === '/' && !currentUser && !hasOnboarded()) {
    window.history.replaceState(null, '', '#/bem-vindo');
    router();
    return;
  }

  if (currentUser && isAuthRoute(hash)) {
    window.history.replaceState(null, '', '#/perfil');
    router();
    return;
  }

  if (!currentUser && ACCOUNT_ROUTES.includes(hash)) {
    window.history.replaceState(null, '', '#/perfil');
    router();
    return;
  }

  if (hash === '/perfil/seguranca' && !canChangePassword()) {
    window.history.replaceState(null, '', '#/perfil');
    router();
    return;
  }

  if (isAuthRoute(hash)) markOnboarded();

  const isImmersive = hash.startsWith('/p/')
    || hash.startsWith('/loja/')
    || hash.startsWith('/carrinho/')
    || hash === '/favoritos'
    || ACCOUNT_ROUTES.includes(hash)
    || isAuthRoute(hash);
  navEl.setAttribute('data-hidden', isImmersive ? 'true' : 'false');

  if (isAuthRoute(hash)) {
    viewEl.innerHTML = renderAuthScreen(hash);
    initAuthScreen(hash);
  } else if (hash.startsWith('/p/')) {
    const productId = hash.split('/')[2];
    viewEl.innerHTML = renderPDP(productId);
    initPDP(productId);
  } else if (hash.startsWith('/loja/')) {
    const storeId = hash.split('/')[2];
    viewEl.innerHTML = renderStore(storeId);
  } else if (hash.startsWith('/carrinho/')) {
    const storeParam = hash.split('/')[2];
    viewEl.innerHTML = renderStoreCart(storeParam);
    initCart();
  } else if (hash === '/') {
    viewEl.innerHTML = renderHome();
    initHome();
  } else if (hash === '/lojas') {
    viewEl.innerHTML = renderStores();
  } else if (hash === '/carrinho') {
    viewEl.innerHTML = renderCartOverview();
    initCart();
  } else if (hash === '/favoritos') {
    viewEl.innerHTML = renderFavorites();
    initFavorites();
  } else if (hash === '/perfil/dados') {
    viewEl.innerHTML = renderAccountData();
    initAccountData();
  } else if (hash === '/perfil/seguranca') {
    viewEl.innerHTML = renderSecurity();
    initSecurity();
  } else if (hash === '/perfil') {
    viewEl.innerHTML = renderProfile();
    initProfile();
  }

  updateHeader(hash);
  updateNavBadge();
  viewEl.removeAttribute('aria-busy');

  tabs.forEach(tab => {
    tab.dataset.route === hash ? tab.setAttribute('aria-current', 'page') : tab.removeAttribute('aria-current');
  });

  window.scrollTo({ top: 0, behavior: 'instant' });
}

window.addEventListener('cart-updated', updateNavBadge);
window.addEventListener('auth-changed', () => {
  if (window.location.hash === '#/perfil' || window.location.hash === '') reRoute();
});

tabs.forEach(tab => tab.addEventListener('click', () => triggerHaptic('light')));

document.addEventListener('keydown', (event) => {
  if (event.key !== 'Enter' && event.key !== ' ') return;
  const target = event.target;
  if (!(target instanceof HTMLElement)) return;
  if (target.closest('input, textarea, select, [contenteditable="true"]')) return;
  const activator = target.closest('[role="button"][tabindex], [role="radio"][tabindex]');
  if (!activator) return;
  event.preventDefault();
  activator.click();
});

if ('serviceWorker' in navigator && window.location.protocol !== 'file:') {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  });
}

initToast();
initSheets();
initSearch();
initLightbox();
initImageLoader();

window.addEventListener('hashchange', router);
router();