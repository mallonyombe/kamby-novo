const CACHE_NAME = 'kamby-static-v6';
const ASSETS = [
  './index.html',
  './manifest.webmanifest',
  './icone.svg',
  './css/tokens.css',
  './css/base.css',
  './css/layout.css',
  './css/components.css',
  './css/skeleton.css',
  './css/screens.css',
  './css/auth.css',
  './js/app.js',
  './js/ui.js',
  './js/skeleton.js',
  './js/data.js',
  './js/cart.js',
  './js/auth.js',
  './js/auth-rules.js',
  './js/favorites.js',
  './js/components/form.js',
  './js/components/product-card.js',
  './js/screens/home.js',
  './js/screens/product.js',
  './js/screens/store.js',
  './js/screens/stores.js',
  './js/screens/cart.js',
  './js/screens/favorites.js',
  './js/screens/account.js',
  './js/screens/security.js',
  './js/screens/profile.js',
  './js/screens/auth.js'
];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS)));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request).catch(() => caches.match('./index.html'))
    );
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request).then((response) => {
        if (response && response.ok) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
        }
        return response;
      });
    })
  );
});
